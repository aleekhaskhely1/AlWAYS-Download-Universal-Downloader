<?php
/**
 * Always Download - Download History API
 * Returns user's download history and allows clearing history
 */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? $_POST['action'] ?? 'get';

if (!$pdo) {
    jsonResponse(false, 'Database service is not connected.');
}

switch ($action) {
    case 'get':
        $userId = isLoggedIn() ? (int)$_SESSION['user']['id'] : null;
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        if ($userId) {
            $stmt = $pdo->prepare("
                SELECT id, item_title, item_category, file_type, file_size, source_url, download_url, created_at
                FROM download_history
                WHERE user_id = ?
                ORDER BY id DESC
                LIMIT 50
            ");
            $stmt->execute([$userId]);
        } else {
            $stmt = $pdo->prepare("
                SELECT id, item_title, item_category, file_type, file_size, source_url, download_url, created_at
                FROM download_history
                WHERE ip_address = ? AND user_id IS NULL
                ORDER BY id DESC
                LIMIT 20
            ");
            $stmt->execute([$ip]);
        }
        $history = $stmt->fetchAll();
        jsonResponse(true, 'History fetched successfully', ['history' => $history]);
        break;

    case 'clear':
        $userId = isLoggedIn() ? (int)$_SESSION['user']['id'] : null;
        if ($userId) {
            $stmt = $pdo->prepare("DELETE FROM download_history WHERE user_id = ?");
            $stmt->execute([$userId]);
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
            $stmt = $pdo->prepare("DELETE FROM download_history WHERE ip_address = ? AND user_id IS NULL");
            $stmt->execute([$ip]);
        }
        jsonResponse(true, 'Download history cleared successfully!');
        break;

    default:
        jsonResponse(false, 'Invalid action');
}
