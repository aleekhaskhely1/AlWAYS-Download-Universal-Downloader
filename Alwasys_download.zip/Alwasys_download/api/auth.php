<?php
/**
 * Always Download - Authentication API Endpoint
 * 100% Secure Password Hashing, Session Management & Google Auth
 */

require_once __DIR__ . '/../config/db.php';

if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Check DB connection
if (!$pdo && in_array($action, ['register', 'login', 'google_auth', 'get_user'])) {
    jsonResponse(false, 'MySQL database service is not running. Please start MySQL from XAMPP Control Panel.', [
        'db_error' => $db_error
    ], 500);
}

switch ($action) {
    case 'register':
        handleRegister($pdo);
        break;

    case 'login':
        handleLogin($pdo);
        break;

    case 'google_auth':
        handleGoogleAuth($pdo);
        break;

    case 'logout':
        handleLogout();
        break;

    case 'get_user':
        handleGetUser();
        break;

    default:
        jsonResponse(false, 'Invalid action specified.', [], 400);
}

/**
 * Handle Registration
 */
function handleRegister($pdo) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(false, 'Only POST requests are allowed.', [], 405);
    }

    $name     = trim($_POST['name'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $email    = trim(strtolower($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if (empty($name) || empty($phone) || empty($email) || empty($password)) {
        jsonResponse(false, 'All fields (Name, Phone, Email, Password) are required.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, 'Please provide a valid Gmail/Email address.');
    }

    if (strlen($password) < 6) {
        jsonResponse(false, 'Password must be at least 6 characters long.');
    }

    // Check if email already registered
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'This Gmail address is already registered. Please Sign In.');
    }

    // Hash password with bcrypt
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    try {
        $insertStmt = $pdo->prepare("
            INSERT INTO users (name, phone, email, password, auth_provider, avatar)
            VALUES (?, ?, ?, ?, 'local', 'default_avatar.svg')
        ");
        $insertStmt->execute([$name, $phone, $email, $hashedPassword]);
        $newUserId = (int)$pdo->lastInsertId();

        // Create user session
        if (!headers_sent()) {
            session_regenerate_id(true);
        }
        $_SESSION['user'] = [
            'id'       => $newUserId,
            'name'     => $name,
            'phone'    => $phone,
            'email'    => $email,
            'provider' => 'local',
            'avatar'   => 'default_avatar.svg'
        ];

        jsonResponse(true, "Registration successful! Welcome, " . htmlspecialchars($name) . "!", [
            'user' => $_SESSION['user']
        ]);
    } catch (PDOException $e) {
        jsonResponse(false, 'Database error: ' . $e->getMessage(), [], 500);
    }
}

/**
 * Handle Login
 */
function handleLogin($pdo) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(false, 'Only POST requests are allowed.', [], 405);
    }

    $email    = trim(strtolower($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        jsonResponse(false, 'Both Email and Password are required.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, 'Please provide a valid Gmail/Email address.');
    }

    $stmt = $pdo->prepare("SELECT id, name, phone, email, password, auth_provider, avatar FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        jsonResponse(false, 'Invalid Email or Password. Please try again.');
    }

    // Success - establish session
    if (!headers_sent()) {
        session_regenerate_id(true);
    }
    $_SESSION['user'] = [
        'id'       => (int)$user['id'],
        'name'     => $user['name'],
        'phone'    => $user['phone'],
        'email'    => $user['email'],
        'provider' => $user['auth_provider'],
        'avatar'   => $user['avatar'] ?: 'default_avatar.svg'
    ];

    jsonResponse(true, "Welcome back, " . htmlspecialchars($user['name']) . "!", [
        'user' => $_SESSION['user']
    ]);
}

/**
 * Handle Google Authentication
 */
function handleGoogleAuth($pdo) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(false, 'Only POST requests are allowed.', [], 405);
    }

    $email  = trim(strtolower($_POST['email'] ?? ''));
    $name   = trim($_POST['name'] ?? '');
    $avatar = trim($_POST['avatar'] ?? 'default_avatar.svg');

    if (empty($email)) {
        jsonResponse(false, 'Google account email not received.');
    }

    if (empty($name)) {
        $name = explode('@', $email)[0];
    }

    // Check if user already exists
    $stmt = $pdo->prepare("SELECT id, name, phone, email, auth_provider, avatar FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        if (!headers_sent()) {
            session_regenerate_id(true);
        }
        $_SESSION['user'] = [
            'id'       => (int)$user['id'],
            'name'     => $user['name'],
            'phone'    => $user['phone'] ?? '',
            'email'    => $user['email'],
            'provider' => 'google',
            'avatar'   => $user['avatar'] ?: $avatar
        ];
        jsonResponse(true, "Signed in with Google successfully! Welcome, " . htmlspecialchars($user['name']) . "!", [
            'user' => $_SESSION['user']
        ]);
    } else {
        $dummyPassword = password_hash(bin2hex(random_bytes(16)), PASSWORD_BCRYPT);
        $insert = $pdo->prepare("
            INSERT INTO users (name, phone, email, password, auth_provider, avatar)
            VALUES (?, '', ?, ?, 'google', ?)
        ");
        $insert->execute([$name, $email, $dummyPassword, $avatar]);
        $newId = (int)$pdo->lastInsertId();

        if (!headers_sent()) {
            session_regenerate_id(true);
        }
        $_SESSION['user'] = [
            'id'       => $newId,
            'name'     => $name,
            'phone'    => '',
            'email'    => $email,
            'provider' => 'google',
            'avatar'   => $avatar
        ];
        jsonResponse(true, "Google account registered and logged in! Welcome, " . htmlspecialchars($name) . "!", [
            'user' => $_SESSION['user']
        ]);
    }
}

/**
 * Handle Logout
 */
function handleLogout() {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    jsonResponse(true, 'Signed out successfully.');
}

/**
 * Get current session user
 */
function handleGetUser() {
    if (isLoggedIn()) {
        jsonResponse(true, 'User logged in', [
            'logged_in' => true,
            'user' => getCurrentUser()
        ]);
    } else {
        jsonResponse(true, 'User guest', [
            'logged_in' => false,
            'user' => null
        ]);
    }
}
