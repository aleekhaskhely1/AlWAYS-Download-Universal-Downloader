<?php
require_once __DIR__ . '/config/db.php';
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AlWay Download - Universal Direct Downloader & Public Media Search</title>
  <meta name="description" content="Search and download YouTube videos, MP3 songs, software EXE, PDF books, code, games, and archives directly for PC and Mobile with 100% verified links.">
  <link rel="icon" type="image/svg+xml" href="assets/images/logo.svg">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

  <!-- Ambient Glowing Backgrounds -->
  <div class="ambient-glow"></div>
  <div class="ambient-glow-2"></div>

  <div class="app-container">
    
    <!-- Top Navigation -->
    <header class="navbar">
      <a href="index.php" class="brand-logo">
        <div class="brand-icon-box">
          <img src="assets/images/logo.svg" alt="AlWay Download Logo">
        </div>
        <div class="brand-text">
          <h1>AlWay Download <span class="brand-badge">PRO</span></h1>
          <p>Universal Direct File Downloader • 100% Free</p>
        </div>
      </a>

      <div class="nav-actions">
        <!-- Download History Toggle Button -->
        <button id="openHistoryBtn" class="nav-btn" title="View Download History">
          <span>📥</span>
          <span class="btn-text">History</span>
          <span id="historyCountBadge" class="history-badge-count">0</span>
        </button>

        <!-- Guest Actions -->
        <div id="guestNavActions" style="<?= $user ? 'display:none;' : 'display:flex;' ?> gap: 8px;">
          <button class="nav-btn open-login-btn">
            <span>🔑</span>
            <span class="btn-text">Sign In</span>
          </button>
          <button class="nav-btn nav-btn-primary open-register-btn">
            <span>✨</span>
            <span class="btn-text">Register</span>
          </button>
        </div>

        <!-- Logged-in User Actions -->
        <div id="userNavActions" class="user-profile-menu" style="<?= $user ? 'display:flex;' : 'display:none;' ?>">
          <button id="userAvatarBtn" class="user-avatar-btn">
            <img id="navUserAvatar" src="<?= htmlspecialchars($user['avatar'] ?? 'assets/images/default_avatar.svg') ?>" alt="User Avatar" class="user-avatar-img" style="width:32px; height:32px; border-radius:50%; object-fit:cover; display:inline-block;">
            <span id="navUserName" class="user-name-text"><?= htmlspecialchars($user['name'] ?? 'User') ?></span>
            <span style="font-size:0.75rem; color:var(--text-dim);">▼</span>
          </button>

          <div id="profileDropdown" class="profile-dropdown">
            <div style="padding: 8px 12px; border-bottom: 1px solid var(--border-glass); margin-bottom: 4px;">
              <div style="font-weight: 700; font-size: 0.88rem; color:#fff;" id="dropdownFullName"><?= $user ? htmlspecialchars($user['name']) : '' ?></div>
              <div style="font-size: 0.75rem; color:var(--accent-cyan); overflow:hidden; text-overflow:ellipsis;" id="dropdownEmail"><?= $user ? htmlspecialchars($user['email']) : '' ?></div>
            </div>
            <a href="dashboard.php" class="dropdown-item">
              <span>👤</span> My Profile & Stats
            </a>
            <a href="#history" class="dropdown-item" onclick="document.getElementById('openHistoryBtn').click();">
              <span>📥</span> My Download History
            </a>
            <button class="dropdown-item logout-btn logout-trigger">
              <span>🚪</span> Sign Out
            </button>
          </div>
        </div>
      </div>
    </header>

    <!-- Hero Section -->
    <section class="hero-section">
      <div class="hero-pill">
        <span>⚡ 100% Free & Unlimited</span>
        <span>•</span>
        <span>No Speed Caps</span>
        <span>•</span>
        <span>PC & Mobile Ready</span>
      </div>

      <h1 class="hero-title">
        Direct Download <span class="glow-gradient">Anything</span>,<br>
        From Anywhere in 1-Click!
      </h1>

      <p class="hero-subtitle">
        Search Google, Web, and Public Archives in real-time to find and download direct <strong>GitHub Repos, All Softwares, iOS Apps & IPAs, HD/4K Images, PDFs, Songs, Movies, and Games</strong> with 100% verified direct links.
      </p>

      <!-- Category Filter Tabs -->
      <div class="categories-wrapper">
        <button class="category-tab active" data-category="all">
          <span class="tab-icon">🌐</span>
          <span>All Files</span>
        </button>
        <button class="category-tab" data-category="github">
          <span class="tab-icon">🐙</span>
          <span>GitHub</span>
        </button>
        <button class="category-tab" data-category="software">
          <span class="tab-icon">💻</span>
          <span>All Softwares</span>
        </button>
        <button class="category-tab" data-category="image">
          <span class="tab-icon">🖼️</span>
          <span>Images & 4K</span>
        </button>
        <button class="category-tab" data-category="pdf">
          <span class="tab-icon">📄</span>
          <span>PDF & Documents</span>
        </button>
        <button class="category-tab" data-category="song">
          <span class="tab-icon">🎵</span>
          <span>Songs & MP3</span>
        </button>
        <button class="category-tab" data-category="movie">
          <span class="tab-icon">🎬</span>
          <span>Movies & Video</span>
        </button>
        <button class="category-tab" data-category="code">
          <span class="tab-icon">📝</span>
          <span>Code & Text</span>
        </button>
        <button class="category-tab" data-category="game">
          <span class="tab-icon">🎮</span>
          <span>Games & PC</span>
        </button>
        <button class="category-tab" data-category="ios">
          <span class="tab-icon">🍏</span>
          <span>iOS & IPA</span>
        </button>
        <button class="category-tab" data-category="archive">
          <span class="tab-icon">📦</span>
          <span>Archives (ZIP/ISO)</span>
        </button>
      </div>

      <!-- Main Universal Search Dialog Box -->
      <div class="search-dialog-container">
        <form id="searchForm" class="search-glow-box">
          <div id="searchCategoryIndicator" class="search-category-indicator">
            <span>🌐</span>
            <span>All Files</span>
          </div>

          <input 
            type="text" 
            id="searchInput" 
            class="search-input-field" 
            placeholder="Type any file name, song, PDF topic, software, or paste direct URL..." 
            autocomplete="off"
            required
          >

          <div class="search-action-tools">
            <button type="button" id="pasteClipboardBtn" class="tool-btn" title="Paste URL from Clipboard">
              📋
            </button>
            <button type="button" id="clearSearchBtn" class="tool-btn" title="Clear input" style="display:none;">
              ✖
            </button>
          </div>

          <button type="submit" class="btn-primary-download">
            <span>⚡</span>
            <span>Direct Download</span>
          </button>
        </form>

        <!-- Live Real-Time Search Suggestions Dropdown -->
        <div id="searchSuggestionsDropdown" class="search-suggestions-dropdown" style="display:none;"></div>

        <!-- Quick Suggestions Chips -->
        <div class="quick-tags-container">
          <span style="color:var(--text-dim); font-weight:600;">Popular Searches:</span>
          <span class="quick-tag-chip" data-query="yt-dlp">🐙 yt-dlp GitHub</span>
          <span class="quick-tag-chip" data-query="VLC Media Player">💻 VLC Media Player</span>
          <span class="quick-tag-chip" data-query="Delta Emulator">🍏 Delta Emulator iOS</span>
          <span class="quick-tag-chip" data-query="Cyberpunk 4K">🖼️ Cyberpunk 4K Wallpaper</span>
          <span class="quick-tag-chip" data-query="Python Cheat Sheet">📄 Python Cheat Sheet PDF</span>
          <span class="quick-tag-chip" data-query="Alan Walker Faded">🎵 Alan Walker Faded MP3</span>
          <span class="quick-tag-chip" data-query="Grand Theft Auto">🎮 GTA PC Games</span>
          <span class="quick-tag-chip" data-query="https://www.youtube.com/watch?v=dQw4w9WgXcQ">🎬 Sample Video URL</span>
        </div>
      </div>

      <!-- Dedicated Direct URL Result Banner -->
      <div id="directUrlCard" class="direct-url-card"></div>

    </section>

    <!-- Results Section -->
    <section class="results-section">
      <div class="results-header-bar">
        <div class="results-title-group">
          <h2>
            <span>⚡ Direct Download Results</span>
            <span id="resultsCountBadge" class="results-counter-pill">Ready</span>
          </h2>
        </div>
        <div style="font-size: 0.85rem; color: var(--text-dim);">
          Direct Public CDN Links • No Waiting • Virus-Free
        </div>
      </div>

      <!-- Dynamic Cards Grid -->
      <div id="resultsGrid" class="results-grid">
        <!-- Loaded via JavaScript AJAX -->
      </div>
    </section>

  </div>

  <!-- Download History Drawer / Sidebar -->
  <div id="drawerOverlay" class="drawer-overlay"></div>
  <aside id="historyDrawer" class="history-drawer">
    <div class="drawer-header">
      <h3 style="font-size:1.1rem; display:flex; align-items:center; gap:8px;">
        <span>📥</span> My Download History
      </h3>
      <button id="closeHistoryBtn" class="modal-close-btn">&times;</button>
    </div>
    <div id="historyDrawerBody" class="drawer-body">
      <!-- Loaded dynamically via history.php -->
    </div>
    <div class="drawer-footer">
      <button id="clearHistoryBtn" class="nav-btn" style="border-color:rgba(239,68,68,0.3); color:#f87171;">
        <span>🗑️</span> Clear All History
      </button>
    </div>
  </aside>

  <!-- Auth Modal (Login / Register / Google) -->
  <div id="authModal" class="modal-overlay">
    <div class="modal-dialog">
      <div class="modal-header">
        <h3 id="authModalTitle" class="modal-title">🔐 Account Authentication</h3>
        <button id="closeAuthBtn" class="modal-close-btn">&times;</button>
      </div>

      <div class="modal-body">
        <!-- Google One-Click Auth Button -->
        <button type="button" class="google-auth-btn">
          <svg viewBox="0 0 48 48">
            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.79l7.97-6.2z"/>
            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
          </svg>
          <span>Continue with Google (Gmail)</span>
        </button>

        <div class="auth-divider">
          <span>OR CONTINUE WITH YOUR EMAIL</span>
        </div>

        <div class="auth-tabs-switch">
          <button type="button" id="tabBtnLogin" class="auth-tab-btn active">Sign In</button>
          <button type="button" id="tabBtnRegister" class="auth-tab-btn">Register</button>
        </div>

        <!-- Login Form -->
        <form id="loginForm">
          <div class="form-group">
            <label class="form-label">Gmail / Email Address</label>
            <input type="email" name="email" class="form-input" placeholder="your.name@gmail.com" required>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-input" placeholder="••••••••" required>
          </div>
          <button type="submit" class="form-submit-btn">🔐 Sign In</button>
        </form>

        <!-- Register Form -->
        <form id="registerForm" style="display:none;">
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input type="text" name="name" class="form-input" placeholder="Alex Morgan" required>
          </div>
          <div class="form-group">
            <label class="form-label">Phone Number</label>
            <input type="tel" name="phone" class="form-input" placeholder="+1 234 567 8900" required>
          </div>
          <div class="form-group">
            <label class="form-label">Gmail / Email Address</label>
            <input type="email" name="email" class="form-input" placeholder="alex@gmail.com" required>
          </div>
          <div class="form-group">
            <label class="form-label">Password (Minimum 6 characters)</label>
            <input type="password" name="password" class="form-input" placeholder="••••••••" minlength="6" required>
          </div>
          <button type="submit" class="form-submit-btn">✨ Create Account</button>
        </form>
      </div>
    </div>
  </div>

  <!-- Media Preview Modal (Player) -->
  <div id="mediaModal" class="modal-overlay">
    <div class="modal-dialog" style="max-width: 650px;">
      <div class="modal-header">
        <h3 id="mediaModalTitle" class="modal-title">Live Preview</h3>
        <button id="closeMediaBtn" class="modal-close-btn">&times;</button>
      </div>
      <div id="mediaModalBody" class="modal-body">
        <!-- Injected via app.js -->
      </div>
    </div>
  </div>

  <!-- Mobile QR Code Modal -->
  <div id="qrModal" class="modal-overlay">
    <div class="modal-dialog" style="max-width: 380px; text-align:center;">
      <div class="modal-header">
        <h3 id="qrModalTitle" class="modal-title">📱 Mobile Direct Download</h3>
        <button id="closeQrBtn" class="modal-close-btn">&times;</button>
      </div>
      <div class="modal-body">
        <p id="qrModalLink" style="font-size:0.85rem; font-weight:700; color:#fff; margin-bottom:14px; word-break:break-all;"></p>
        <div id="qrCodeContainer" style="display:flex; flex-direction:column; align-items:center;">
          <!-- QR Code Image -->
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="app-footer">
    <div class="app-container">
      <div style="margin-bottom:8px; font-weight:700; color:var(--text-main);">
        ⚡ AlWay Download — Advanced Universal Public Downloader
      </div>
      <p>
        Engineered for <strong>24959_khaskheli</strong> • Powered by PHP, MySQL, JavaScript & AJAX
      </p>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="assets/js/toast.js"></script>
  <script src="assets/js/auth.js"></script>
  <script src="assets/js/app.js"></script>
</body>
</html>
