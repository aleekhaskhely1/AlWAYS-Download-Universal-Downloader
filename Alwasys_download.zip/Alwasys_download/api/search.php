<?php
/**
 * Always Download - Smart AI Direct Search Engine & Deep Link Crawler (V3)
 * 100% Relevant Results • Deep Landing Page Crawler • Zero Noise / Junk Filter
 * Categories: GitHub, All Softwares, iOS & IPA, Images & 4K, PDFs, Songs, Movies, Games, Code, Archives, All
 */

require_once __DIR__ . '/../config/db.php';

// Release session lock immediately to allow fast, non-blocking concurrent searches
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
}

$query    = trim($_GET['q'] ?? '');
$category = strtolower(trim($_GET['category'] ?? 'all'));

if (empty($query)) {
    jsonResponse(false, 'Please enter a name to search.');
}

// If user happens to paste a direct URL, route to direct URL inspector
if (preg_match('~^(?:f|ht)tps?://~i', $query)) {
    header("Location: direct_url.php?url=" . urlencode($query));
    exit;
}

$results = [];

switch ($category) {
    case 'github':
    case 'git':
    case 'repo':
        $results = searchDirectGitHubByName($query);
        break;

    case 'software':
    case 'softwares':
    case 'exe':
    case 'app':
    case 'apps':
        $results = searchDirectAllSoftwaresByName($query);
        break;

    case 'ios':
    case 'ipa':
    case 'apple':
        $results = searchDirectIosByName($query);
        break;

    case 'image':
    case 'images':
    case 'wallpaper':
    case 'wallpapers':
    case 'photo':
        $results = searchDirectImagesByName($query);
        break;

    case 'song':
    case 'mp3':
    case 'audio':
    case 'music':
        $results = searchDirectSongsByName($query);
        break;

    case 'movie':
    case 'video':
    case 'film':
        $results = searchDirectMoviesByName($query);
        break;

    case 'pdf':
    case 'book':
    case 'books':
    case 'document':
        $results = searchDirectPdfsByName($query);
        break;

    case 'game':
    case 'games':
    case 'rom':
        $results = searchDirectGamesByName($query);
        break;

    case 'code':
    case 'text':
    case 'script':
        $results = searchDirectCodeByName($query);
        break;

    case 'archive':
    case 'zip':
    case 'rar':
    case '7z':
        $results = searchDirectArchivesByName($query);
        break;

    case 'all':
    default:
        $results = searchDirectAllByName($query);
        break;
}

// Only for 'all' category: if empty, try GitHub with strict scoring
if (empty($results) && $category === 'all') {
    $fallback = searchDirectGitHubByName($query);
    $results = filterAndRankResults($query, $fallback, 'all', 40);
}

$msg = count($results) > 0 
    ? count($results) . " verified results found!" 
    : "No verified direct downloads matched your query in this category.";

jsonResponse(true, $msg, [
    'query'    => $query,
    'category' => $category,
    'count'    => count($results),
    'results'  => $results
]);

/**
 * Smart AI Relevance Scorer (0 - 100)
 * Evaluates semantic match between search query and candidate items.
 * Discards unwanted noise, third-party spam, and unrelated documents.
 */
function calculateRelevanceScore($query, $title, $description = '', $category = '', $fileType = '') {
    $stopWords = [
        'download', 'free', 'the', 'a', 'an', 'and', 'or', 'in', 'on', 'at', 'to', 'for', 
        'of', 'with', 'by', 'pc', 'file', 'official', 'latest', 'version', 'full', 'hd', 
        'online', 'installer', 'setup', 'app', 'apps', 'software', 'softwares', 'windows', 
        'mac', 'linux', 'android', 'portable', 'wallpaper', 'wallpapers', '4k', '8k', 'uhd', 
        'photo', 'video', 'trailer'
    ];

    $cleanQuery = strtolower(trim(preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $query)));
    $cleanTitle = strtolower(trim(preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $title)));
    $cleanDesc  = strtolower(trim(preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $description)));

    if (empty($cleanQuery) || empty($cleanTitle)) return 0;

    $queryTokens = array_values(array_filter(explode(' ', $cleanQuery), fn($w) => strlen($w) >= 2 && !in_array($w, $stopWords)));
    if (empty($queryTokens)) {
        $queryTokens = array_values(array_filter(explode(' ', $cleanQuery), fn($w) => strlen($w) >= 2));
    }
    if (empty($queryTokens)) return 50;

    $score = 0;

    // 1. Exact phrase match in title
    if (str_contains($cleanTitle, $cleanQuery)) {
        $score += 50;
    } else {
        // Bigram / phrase sequence match
        for ($i = 0; $i < count($queryTokens) - 1; $i++) {
            $bigram = $queryTokens[$i] . ' ' . $queryTokens[$i + 1];
            if (str_contains($cleanTitle, $bigram)) {
                $score += 30;
                break;
            }
        }
    }

    // 2. Token coverage across title and description
    $titleMatches = 0;
    $descMatches = 0;
    foreach ($queryTokens as $token) {
        if (str_contains($cleanTitle, $token)) {
            $titleMatches++;
        } else if (!empty($cleanDesc) && str_contains($cleanDesc, $token)) {
            $descMatches++;
        }
    }

    $titleRatio = $titleMatches / count($queryTokens);
    $totalRatio = ($titleMatches + $descMatches) / count($queryTokens);

    $score += ($titleRatio * 35);
    $score += ($totalRatio * 25);

    // Strict penalty if total keyword match across title and desc is low
    if ($totalRatio < 0.40) {
        $score -= 40;
    }

    // 3. Category alignment boost
    $catLower = strtolower($category);
    $typeLower = strtolower($fileType);
    if (str_contains($catLower, 'song') || str_contains($catLower, 'audio')) {
        if (in_array($typeLower, ['mp3', 'flac', 'wav', 'audio'])) $score += 10;
    } else if (str_contains($catLower, 'software') || str_contains($catLower, 'app') || str_contains($catLower, 'ios')) {
        if (in_array($typeLower, ['exe', 'msi', 'dmg', 'pkg', 'apk', 'ipa', 'appimage', 'deb', 'zip'])) $score += 10;
    } else if (str_contains($catLower, 'movie') || str_contains($catLower, 'video')) {
        if (in_array($typeLower, ['mp4', 'mkv', 'avi', 'webm', 'video'])) $score += 10;
    } else if (str_contains($catLower, 'pdf') || str_contains($catLower, 'book')) {
        if (in_array($typeLower, ['pdf', 'epub'])) $score += 10;
    } else if (str_contains($catLower, 'image') || str_contains($catLower, 'wallpaper')) {
        if (in_array($typeLower, ['jpg', 'jpeg', 'png', 'webp', 'svg', 'gif'])) $score += 10;
    } else if (str_contains($catLower, 'code') || str_contains($catLower, 'archive') || str_contains($catLower, 'zip')) {
        if (in_array($typeLower, ['zip', 'repo', 'tar', 'gz', '7z', 'rar', 'iso'])) $score += 10;
    }

    return min(100, max(0, (int)round($score)));
}

/**
 * Filter items by relevance and sort by quality rank
 */
function filterAndRankResults($query, array $items, $category, $minScore = 40) {
    $ranked = [];
    $seenUrls = [];

    foreach ($items as $item) {
        $url = $item['direct_url'] ?? '';
        if (empty($url) || isset($seenUrls[$url])) continue;
        $seenUrls[$url] = true;

        $title = $item['title'] ?? '';
        $desc  = $item['description'] ?? '';
        $fileType = $item['file_type'] ?? '';
        $score = calculateRelevanceScore($query, $title, $desc, $category, $fileType);

        if ($score >= $minScore) {
            $item['relevance_score'] = $score;
            $ranked[] = $item;
        }
    }

    usort($ranked, fn($a, $b) => ($b['relevance_score'] ?? 0) <=> ($a['relevance_score'] ?? 0));
    return $ranked;
}

/**
 * Deep Landing Page Crawler & Direct Link Extractor
 * Crawls official product pages to extract real direct binary/media download URLs
 */
function crawlForDirectDownload($landingUrl, array $targetExts) {
    if (empty($landingUrl) || !filter_var($landingUrl, FILTER_VALIDATE_URL)) return null;

    $ch = curl_init($landingUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $html = curl_exec($ch);
    $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?: $landingUrl;
    curl_close($ch);

    if (!$html) return null;

    $baseParsed = parse_url($finalUrl);
    $baseHost = ($baseParsed['scheme'] ?? 'https') . '://' . ($baseParsed['host'] ?? '');

    if (preg_match_all('/<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $href = trim($m[1]);
            $anchorText = trim(strip_tags($m[2]));
            if (empty($href) || str_starts_with($href, '#') || str_starts_with($href, 'javascript:')) continue;

            if (str_starts_with($href, '//')) {
                $fullUrl = ($baseParsed['scheme'] ?? 'https') . ':' . $href;
            } else if (str_starts_with($href, '/')) {
                $fullUrl = $baseHost . $href;
            } else if (!preg_match('~^https?://~i', $href)) {
                $fullUrl = rtrim($finalUrl, '/') . '/' . $href;
            } else {
                $fullUrl = $href;
            }

            $path = parse_url($fullUrl, PHP_URL_PATH) ?: '';
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

            if (in_array($ext, $targetExts)) {
                return [
                    'direct_url' => $fullUrl,
                    'ext'        => strtoupper($ext),
                    'text'       => $anchorText
                ];
            }
        }
    }
    return null;
}

/**
 * Curated Top Software Official Direct CDN Library
 */
function getCuratedSoftware($query) {
    $catalog = [
        'vlc' => [
            'name' => 'VLC Media Player (Official 64-bit Windows Installer)',
            'type' => 'EXE',
            'size' => '42.3 MB • Official Release',
            'url'  => 'https://get.videolan.org/vlc/3.0.21/win64/vlc-3.0.21-win64.exe',
            'desc' => 'Official VideoLAN Open-Source Cross-Platform Media Player for Windows',
            'thumb'=> 'https://images.videolan.org/images/icons-VLC/vlc.mini.svg'
        ],
        '7-zip' => [
            'name' => '7-Zip High-Ratio Archive Manager (Official 64-bit)',
            'type' => 'EXE',
            'size' => '1.5 MB • Official Installer',
            'url'  => 'https://www.7-zip.org/a/7z2409-x64.exe',
            'desc' => 'Free and Open Source File Archiver with high compression ratio',
            'thumb'=> 'https://www.7-zip.org/7ziplogo.png'
        ],
        '7zip' => [
            'name' => '7-Zip High-Ratio Archive Manager (Official 64-bit)',
            'type' => 'EXE',
            'size' => '1.5 MB • Official Installer',
            'url'  => 'https://www.7-zip.org/a/7z2409-x64.exe',
            'desc' => 'Free and Open Source File Archiver with high compression ratio',
            'thumb'=> 'https://www.7-zip.org/7ziplogo.png'
        ],
        'notepad++' => [
            'name' => 'Notepad++ Source Code Editor (Official x64 Installer)',
            'type' => 'EXE',
            'size' => '4.6 MB • Official Release',
            'url'  => 'https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.7.7/npp.8.7.7.Installer.x64.exe',
            'desc' => 'Free source code editor and Notepad replacement supporting multiple languages',
            'thumb'=> 'https://notepad-plus-plus.org/assets/images/nppHeroImage.png'
        ],
        'notepad' => [
            'name' => 'Notepad++ Source Code Editor (Official x64 Installer)',
            'type' => 'EXE',
            'size' => '4.6 MB • Official Release',
            'url'  => 'https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.7.7/npp.8.7.7.Installer.x64.exe',
            'desc' => 'Free source code editor and Notepad replacement supporting multiple languages',
            'thumb'=> 'https://notepad-plus-plus.org/assets/images/nppHeroImage.png'
        ],
        'blender' => [
            'name' => 'Blender 3D Suite (Official Windows MSI Installer)',
            'type' => 'MSI',
            'size' => '348 MB • Official Installer',
            'url'  => 'https://download.blender.org/release/Blender4.3/blender-4.3.2-windows-x64.msi',
            'desc' => 'Open Source 3D Creation Suite: Modeling, Rigging, Animation, Simulation, Rendering',
            'thumb'=> 'https://download.blender.org/branding/blender_logo_socket.png'
        ],
        'obs' => [
            'name' => 'OBS Studio (Open Broadcaster Software Windows Installer)',
            'type' => 'EXE',
            'size' => '130 MB • Official Release',
            'url'  => 'https://github.com/obsproject/obs-studio/releases/download/31.0.2/OBS-Studio-31.0.2-Windows-Installer.exe',
            'desc' => 'Free and open source software for video recording and live streaming',
            'thumb'=> 'https://obsproject.com/assets/images/logo.png'
        ],
        'vscode' => [
            'name' => 'Visual Studio Code (Official 64-bit User Installer)',
            'type' => 'EXE',
            'size' => '95 MB • Official Microsoft Release',
            'url'  => 'https://update.code.visualstudio.com/latest/win32-x64-user/stable',
            'desc' => 'Code editing redefined. Free, open source editor for Windows, Mac, and Linux',
            'thumb'=> 'https://code.visualstudio.com/favicon.ico'
        ],
        'git' => [
            'name' => 'Git for Windows (Official 64-bit Installer)',
            'type' => 'EXE',
            'size' => '62 MB • Official Release',
            'url'  => 'https://github.com/git-for-windows/git/releases/download/v2.48.1.windows.1/Git-2.48.1-64-bit.exe',
            'desc' => 'Fast, scalable, distributed revision control system with an unusually rich command set',
            'thumb'=> 'https://git-scm.com/favicon.ico'
        ],
        'python' => [
            'name' => 'Python 3.12 (Official Windows 64-bit Installer)',
            'type' => 'EXE',
            'size' => '25.4 MB • Official Python PSF',
            'url'  => 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe',
            'desc' => 'Python is a programming language that lets you work quickly and integrate systems more effectively',
            'thumb'=> 'https://www.python.org/static/favicon.ico'
        ],
        'gimp' => [
            'name' => 'GIMP Image Editor (Official Windows Installer)',
            'type' => 'EXE',
            'size' => '310 MB • Official Release',
            'url'  => 'https://download.gimp.org/gimp/v3.0/windows/gimp-3.0.0-setup.exe',
            'desc' => 'GNU Image Manipulation Program: Free & Open Source Image Editor',
            'thumb'=> 'https://www.gimp.org/images/frontpage/wilber-big.png'
        ],
        'audacity' => [
            'name' => 'Audacity Audio Editor (Official 64-bit Installer)',
            'type' => 'EXE',
            'size' => '15 MB • Official Release',
            'url'  => 'https://github.com/audacity/audacity/releases/download/Audacity-3.7.1/audacity-win-3.7.1-64bit.exe',
            'desc' => 'Easy-to-use, multi-track audio editor and recorder for Windows, macOS, and Linux',
            'thumb'=> 'https://www.audacityteam.org/favicon.ico'
        ],
        'handbrake' => [
            'name' => 'HandBrake Video Transcoder (Official x64 Installer)',
            'type' => 'EXE',
            'size' => '24 MB • Official Release',
            'url'  => 'https://github.com/HandBrake/HandBrake/releases/download/1.9.1/HandBrake-1.9.1-x86_64-Win_GUI.exe',
            'desc' => 'The open source video transcoder: convert video from nearly any format',
            'thumb'=> 'https://handbrake.fr/img/favicon.ico'
        ],
        'rufus' => [
            'name' => 'Rufus USB Formatter & Bootable Creator (Portable x64)',
            'type' => 'EXE',
            'size' => '1.7 MB • Official Portable',
            'url'  => 'https://github.com/pbatard/rufus/releases/download/v4.6/rufus-4.6.exe',
            'desc' => 'Create bootable USB drives the easy way: Windows, Linux, and UEFI supported',
            'thumb'=> 'https://rufus.ie/pics/rufus-128.png'
        ],
        'filezilla' => [
            'name' => 'FileZilla Client (Official Windows 64-bit Installer)',
            'type' => 'EXE',
            'size' => '12.4 MB • Official Release',
            'url'  => 'https://download.filezilla-project.org/client/FileZilla_3.68.1_win64_sponsored-setup.exe',
            'desc' => 'Free FTP solution: open source FTP client and FTP server',
            'thumb'=> 'https://filezilla-project.org/images/favicon.ico'
        ]
    ];

    $matches = [];
    $clean = strtolower(trim(preg_replace('/[^a-zA-Z0-9]/', '', $query)));

    foreach ($catalog as $key => $app) {
        if ($clean === $key || str_contains($clean, $key) || str_contains($key, $clean)) {
            $matches[] = [
                'id'           => 'curated_' . $key,
                'title'        => $app['name'],
                'category'     => 'All Softwares',
                'file_type'    => $app['type'],
                'file_size'    => $app['size'],
                'description'  => $app['desc'] . ' • 100% Direct Official Installer',
                'thumbnail'    => $app['thumb'],
                'direct_url'   => $app['url'],
                'stream_url'   => $app['url'],
                'preview_type' => 'link',
                'preview_url'  => $app['url'],
                'source'       => 'Official Software Vendor CDN'
            ];
        }
    }
    return $matches;
}

/**
 * 1. Search GitHub Repositories & Binary Releases
 */
function searchDirectGitHubByName($query) {
    $items = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return $items;

    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "&sort=stars&per_page=8";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    $repos = [];
    if ($res) {
        $data = json_decode($res, true);
        if (!isset($data['message']) || !str_contains(strtolower($data['message']), 'rate limit')) {
            $repos = $data['items'] ?? [];
        }
    }

    // Fallback if rate limited: parse Bing site:github.com
    if (empty($repos)) {
        $bingGh = searchWebSearchEngine("site:github.com " . $cleanQuery, "ZIP", "GitHub Repo", "REPO", 6);
        foreach ($bingGh as $bItem) {
            $url = $bItem['direct_url'];
            if (preg_match('~github\.com/([a-zA-Z0-9_.-]+)/([a-zA-Z0-9_.-]+)~', $url, $m)) {
                $fullName = "{$m[1]}/{$m[2]}";
                $repoName = $m[2];
                $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/main.zip";
                $items[] = [
                    'id'           => 'gh_bing_' . md5($fullName),
                    'title'        => "{$repoName} (Complete Source Code .ZIP)",
                    'category'     => 'GitHub Repo',
                    'file_type'    => 'REPO',
                    'file_size'    => "GitHub Repository",
                    'description'  => "Official Open Source Repository • Direct Archive Package",
                    'thumbnail'    => "https://github.githubassets.com/favicons/favicon.png",
                    'direct_url'   => $zipUrl,
                    'stream_url'   => $zipUrl,
                    'preview_type' => 'link',
                    'preview_url'  => "https://github.com/{$fullName}",
                    'source'       => "GitHub ({$fullName})"
                ];
            }
        }
    } else {
        $mh = curl_multi_init();
        $handles = [];
        $inspectCount = min(count($repos), 4);

        for ($i = 0; $i < $inspectCount; $i++) {
            $fullName = $repos[$i]['full_name'];
            $relUrl = "https://api.github.com/repos/{$fullName}/releases/latest";
            $chRel = curl_init($relUrl);
            curl_setopt($chRel, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($chRel, CURLOPT_TIMEOUT, 2);
            curl_setopt($chRel, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
            curl_setopt($chRel, CURLOPT_SSL_VERIFYPEER, false);
            curl_multi_add_handle($mh, $chRel);
            $handles[$fullName] = $chRel;
        }

        $running = null;
        do {
            curl_multi_exec($mh, $running);
            curl_multi_select($mh, 0.1);
        } while ($running > 0);

        $releasesMap = [];
        foreach ($handles as $fullName => $chRel) {
            $relRaw = curl_multi_getcontent($chRel);
            curl_multi_remove_handle($mh, $chRel);
            curl_close($chRel);
            if ($relRaw) {
                $releasesMap[$fullName] = json_decode($relRaw, true);
            }
        }
        curl_multi_close($mh);

        foreach ($repos as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $desc = $repo['description'] ?? 'Official Open Source GitHub Repository';
            $avatar = $repo['owner']['avatar_url'] ?? 'https://github.githubassets.com/favicons/favicon.png';
            $defaultBranch = $repo['default_branch'] ?? 'main';
            $language = $repo['language'] ?? 'Source Code';
            $repoUrl = $repo['html_url'] ?? "https://github.com/{$fullName}";

            $relData = $releasesMap[$fullName] ?? null;
            if ($relData && !empty($relData['assets'])) {
                $tag = $relData['tag_name'] ?? 'latest';
                foreach ($relData['assets'] as $asset) {
                    $assetName = $asset['name'] ?? '';
                    $ext = strtolower(pathinfo($assetName, PATHINFO_EXTENSION));
                    if (in_array($ext, ['exe', 'msi', 'zip', 'dmg', 'pkg', 'apk', 'ipa', 'deb', 'appimage', 'gz'])) {
                        $dlUrl = $asset['browser_download_url'];
                        $size = isset($asset['size']) ? formatBytesEng($asset['size']) : 'Official Release';
                        $typeLabel = strtoupper($ext);
                        if ($typeLabel === 'GZ') $typeLabel = 'TAR.GZ';

                        $items[] = [
                            'id'           => 'gh_rel_' . ($asset['id'] ?? uniqid()),
                            'title'        => "{$repoName} ({$tag}) - {$assetName}",
                            'category'     => 'GitHub Release',
                            'file_type'    => $typeLabel,
                            'file_size'    => $size,
                            'description'  => "Official Binary Release • ★ {$stars} Stars • {$desc}",
                            'thumbnail'    => $avatar,
                            'direct_url'   => $dlUrl,
                            'stream_url'   => $dlUrl,
                            'preview_type' => 'link',
                            'preview_url'  => $repoUrl,
                            'source'       => "GitHub Releases ({$fullName})"
                        ];
                        break;
                    }
                }
            }

            $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/{$defaultBranch}.zip";
            $items[] = [
                'id'           => 'gh_repo_' . $repo['id'],
                'title'        => "{$repoName} (Complete Source Code .ZIP)",
                'category'     => 'GitHub Repo',
                'file_type'    => 'REPO',
                'file_size'    => "★ {$stars} Stars • {$language}",
                'description'  => "Official Repository Package • {$desc}",
                'thumbnail'    => $avatar,
                'direct_url'   => $zipUrl,
                'stream_url'   => $zipUrl,
                'preview_type' => 'link',
                'preview_url'  => $repoUrl,
                'source'       => "GitHub ({$fullName})"
            ];

            if (count($items) >= 10) break;
        }
    }

    return filterAndRankResults($cleanQuery, $items, 'github', 40);
}

/**
 * 2. Search All Softwares (Windows EXE/MSI, Mac DMG, Android APK, Linux AppImage)
 */
function searchDirectAllSoftwaresByName($query) {
    $items = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return $items;

    // A. Check curated catalog for instant official downloads
    $curated = getCuratedSoftware($cleanQuery);
    if (!empty($curated)) {
        $items = array_merge($items, $curated);
    }

    // B. Search GitHub for multi-platform binaries (.exe, .msi, .dmg, .apk, .deb, .appimage, .zip)
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "+in:name,description&sort=stars&per_page=6";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        $repos = $data['items'] ?? [];

        $mh = curl_multi_init();
        $handles = [];
        $inspectCount = min(count($repos), 4);

        for ($i = 0; $i < $inspectCount; $i++) {
            $fullName = $repos[$i]['full_name'];
            $relUrl = "https://api.github.com/repos/{$fullName}/releases/latest";
            $chRel = curl_init($relUrl);
            curl_setopt($chRel, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($chRel, CURLOPT_TIMEOUT, 2);
            curl_setopt($chRel, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
            curl_setopt($chRel, CURLOPT_SSL_VERIFYPEER, false);
            curl_multi_add_handle($mh, $chRel);
            $handles[$fullName] = $chRel;
        }

        $running = null;
        do {
            curl_multi_exec($mh, $running);
            curl_multi_select($mh, 0.1);
        } while ($running > 0);

        $releasesMap = [];
        foreach ($handles as $fullName => $chRel) {
            $relRaw = curl_multi_getcontent($chRel);
            curl_multi_remove_handle($mh, $chRel);
            curl_close($chRel);
            if ($relRaw) {
                $releasesMap[$fullName] = json_decode($relRaw, true);
            }
        }
        curl_multi_close($mh);

        foreach ($repos as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $desc = $repo['description'] ?? 'Official Software Release';
            $avatar = $repo['owner']['avatar_url'] ?? '';

            $relData = $releasesMap[$fullName] ?? null;
            $assetCount = 0;

            if ($relData && !empty($relData['assets'])) {
                $tag = $relData['tag_name'] ?? 'latest';
                foreach ($relData['assets'] as $asset) {
                    $assetName = $asset['name'] ?? '';
                    $ext = strtolower(pathinfo($assetName, PATHINFO_EXTENSION));
                    if (in_array($ext, ['exe', 'msi', 'zip', 'dmg', 'pkg', 'apk', 'ipa', 'deb', 'appimage'])) {
                        $dlUrl = $asset['browser_download_url'];
                        $size = isset($asset['size']) ? formatBytesEng($asset['size']) : 'Binary Release';

                        $osBadge = 'PC / All';
                        if (in_array($ext, ['exe', 'msi'])) $osBadge = 'Windows';
                        else if (in_array($ext, ['dmg', 'pkg'])) $osBadge = 'macOS';
                        else if (in_array($ext, ['apk'])) $osBadge = 'Android';
                        else if (in_array($ext, ['ipa'])) $osBadge = 'iOS';
                        else if (in_array($ext, ['deb', 'appimage'])) $osBadge = 'Linux';

                        $items[] = [
                            'id'           => 'soft_gh_' . ($asset['id'] ?? uniqid()),
                            'title'        => "{$repoName} ({$osBadge}) - {$assetName}",
                            'category'     => 'All Softwares',
                            'file_type'    => strtoupper($ext),
                            'file_size'    => "{$osBadge} • {$size}",
                            'description'  => "Official Binary Release ({$tag}) • ★ {$stars} Stars • {$desc}",
                            'thumbnail'    => $avatar,
                            'direct_url'   => $dlUrl,
                            'stream_url'   => $dlUrl,
                            'preview_type' => 'link',
                            'preview_url'  => "https://github.com/{$fullName}",
                            'source'       => "GitHub Official ({$fullName})"
                        ];
                        $assetCount++;
                        if ($assetCount >= 2) break;
                    }
                }
            }
        }
    }

    // C. Deep Crawl Web Landing Pages for Direct Installer Binaries
    $webSoftware = searchWebSearchEngine("download {$cleanQuery} official", 'exe', 'All Softwares', 'EXE', 3);
    foreach ($webSoftware as $webItem) {
        $crawled = crawlForDirectDownload($webItem['direct_url'], ['exe', 'msi', 'dmg', 'pkg', 'zip']);
        if ($crawled) {
            $webItem['direct_url'] = $crawled['direct_url'];
            $webItem['stream_url'] = $crawled['direct_url'];
            $webItem['file_type']  = $crawled['ext'];
            $webItem['title']      = "{$cleanQuery} Official Direct Installer ({$crawled['ext']})";
            $webItem['description']= "Deep Crawled Direct Download Link • 1-Click Forced Save";
            $items[] = $webItem;
        }
    }

    // D. Archive.org verified software packages
    $iaSoftware = searchArchiveOrgFast($cleanQuery, 'software', ['exe', 'msi', 'zip', 'iso'], 'All Softwares', 'EXE', 3);
    $items = array_merge($items, $iaSoftware);

    return filterAndRankResults($cleanQuery, $items, 'software', 40);
}

function searchDirectSoftwareByName($query) {
    return searchDirectAllSoftwaresByName($query);
}

/**
 * 3. Search iOS Applications & IPAs
 */
function searchDirectIosByName($query) {
    $items = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return $items;

    // A. Apple iTunes Search API for official App Store applications
    $itunesUrl = "https://itunes.apple.com/search?term=" . urlencode($cleanQuery) . "&entity=software&limit=6";
    $ch = curl_init($itunesUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlwaysDownloadApp/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        foreach ($data['results'] ?? [] as $app) {
            $name = $app['trackName'] ?? 'iOS App';
            $price = $app['formattedPrice'] ?? 'Free';
            $bytes = $app['fileSizeBytes'] ?? 0;
            $sizeStr = $bytes > 0 ? round($bytes / (1024 * 1024), 1) . ' MB' : 'Official App';
            $icon = $app['artworkUrl512'] ?? ($app['artworkUrl100'] ?? '');
            $appUrl = $app['trackViewUrl'] ?? '';
            $bundleId = $app['bundleId'] ?? '';
            $genres = implode(', ', $app['genres'] ?? ['iOS App']);

            $items[] = [
                'id'           => 'ios_' . ($app['trackId'] ?? uniqid()),
                'title'        => "{$name} (Official iOS App)",
                'category'     => 'iOS & IPA',
                'file_type'    => 'IPA',
                'file_size'    => "iOS App • {$sizeStr} • {$price}",
                'description'  => "Official Apple App Store Package • {$genres} • Bundle: {$bundleId}",
                'thumbnail'    => $icon,
                'direct_url'   => $appUrl,
                'stream_url'   => $appUrl,
                'preview_type' => 'link',
                'preview_url'  => $appUrl,
                'source'       => 'Apple App Store'
            ];
        }
    }

    // B. GitHub iOS Sideloadable IPAs (Delta, PPSSPP, TrollStore, etc.)
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "+(ipa+OR+ios)&sort=stars&per_page=4";
    $ch2 = curl_init($ghUrl);
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch2, CURLOPT_USERAGENT, 'AlwaysDownloadApp/2.0');
    curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
    $ghRes = curl_exec($ch2);
    curl_close($ch2);

    if ($ghRes) {
        $ghData = json_decode($ghRes, true);
        foreach ($ghData['items'] ?? [] as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $desc = $repo['description'] ?? 'Open-Source iOS Project';

            $relUrl = "https://api.github.com/repos/{$fullName}/releases/latest";
            $chRel = curl_init($relUrl);
            curl_setopt($chRel, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($chRel, CURLOPT_TIMEOUT, 2);
            curl_setopt($chRel, CURLOPT_USERAGENT, 'AlwaysDownloadApp/2.0');
            curl_setopt($chRel, CURLOPT_SSL_VERIFYPEER, false);
            $relRes = curl_exec($chRel);
            curl_close($chRel);

            if ($relRes) {
                $relData = json_decode($relRes, true);
                foreach ($relData['assets'] ?? [] as $asset) {
                    $assetName = $asset['name'] ?? '';
                    if (str_ends_with(strtolower($assetName), '.ipa') || str_ends_with(strtolower($assetName), '.zip')) {
                        $items[] = [
                            'id'           => 'gh_ipa_' . ($asset['id'] ?? uniqid()),
                            'title'        => "{$repoName} (Sideloadable IPA) - {$assetName}",
                            'category'     => 'iOS & IPA',
                            'file_type'    => 'IPA',
                            'file_size'    => 'Sideloadable IPA • ★ ' . $stars . ' Stars',
                            'description'  => "Direct Sideloadable iOS Binary • AltStore / TrollStore Ready • {$desc}",
                            'thumbnail'    => $repo['owner']['avatar_url'] ?? '',
                            'direct_url'   => $asset['browser_download_url'],
                            'stream_url'   => $asset['browser_download_url'],
                            'preview_type' => 'link',
                            'preview_url'  => "https://github.com/{$fullName}",
                            'source'       => "GitHub Releases ({$fullName})"
                        ];
                        break;
                    }
                }
            }
        }
    }

    return filterAndRankResults($cleanQuery, $items, 'iOS & IPA', 40);
}

/**
 * 4. Search High-Definition Images & 4K Wallpapers
 */
function searchDirectImagesByName($query) {
    $items = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_]/u', ' ', $query));
    if (empty($cleanQuery)) return $items;

    // Strip image category buzzwords so Wallhaven / Openverse tag search finds exact matches
    $stopWords = ['wallpaper', 'wallpapers', '4k', '8k', 'hd', 'uhd', 'photo', 'photos', 'image', 'images', 'pic', 'pics', 'picture', 'pictures', 'background', 'download', 'ultra'];
    $tokens = preg_split('/\s+/', strtolower($cleanQuery));
    $filtered = array_values(array_filter($tokens, fn($t) => !in_array($t, $stopWords) && strlen($t) >= 2));
    $keyword = !empty($filtered) ? implode(' ', $filtered) : $cleanQuery;

    // A. Wallhaven 4K/8K Ultra HD Wallpapers API
    $whUrl = "https://wallhaven.cc/api/v1/search?q=" . urlencode($keyword) . "&categories=111&purity=100&sorting=relevance";
    $ch = curl_init($whUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $whRes = curl_exec($ch);
    curl_close($ch);

    if ($whRes) {
        $whData = json_decode($whRes, true);
        foreach ($whData['data'] ?? [] as $wItem) {
            $imgUrl = $wItem['path'] ?? '';
            if (empty($imgUrl)) continue;
            $thumbUrl = $wItem['thumbs']['original'] ?? ($wItem['thumbs']['small'] ?? $imgUrl);
            $resolution = $wItem['resolution'] ?? 'HD';
            $fileSize = isset($wItem['file_size']) ? formatBytesEng($wItem['file_size']) : '4K Image';
            $ext = strtoupper(pathinfo(parse_url($imgUrl, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'JPG');

            $qualityBadge = "{$resolution} • {$fileSize}";
            if (str_contains($resolution, '3840x') || str_contains($resolution, '7680x')) {
                $qualityBadge = "4K/8K UHD • " . $qualityBadge;
            } else if (str_contains($resolution, '1920x')) {
                $qualityBadge = "1080p FHD • " . $qualityBadge;
            }

            $items[] = [
                'id'           => 'wh_' . ($wItem['id'] ?? uniqid()),
                'title'        => "{$cleanQuery} HD Wallpaper (" . ($wItem['id'] ?? 'Ultra') . ")",
                'category'     => 'Images & 4K',
                'file_type'    => $ext,
                'file_size'    => $qualityBadge,
                'description'  => "Ultra High Resolution 4K/8K • Wallhaven Verified Direct CDN",
                'thumbnail'    => $thumbUrl,
                'direct_url'   => $imgUrl,
                'stream_url'   => $imgUrl,
                'preview_type' => 'image',
                'preview_url'  => $imgUrl,
                'source'       => 'Wallhaven 4K CDN'
            ];
            if (count($items) >= 8) break;
        }
    }

    // B. Openverse Public Images API
    $ovUrl = "https://api.openverse.org/v1/images/?q=" . urlencode($keyword) . "&page_size=8";
    $ch = curl_init($ovUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $ovRes = curl_exec($ch);
    curl_close($ch);

    if ($ovRes) {
        $ovData = json_decode($ovRes, true);
        foreach ($ovData['results'] ?? [] as $oItem) {
            $imgUrl = $oItem['url'] ?? '';
            if (empty($imgUrl)) continue;
            $thumbUrl = $oItem['thumbnail'] ?? $imgUrl;
            $title = !empty($oItem['title']) ? $oItem['title'] : "{$cleanQuery} High-Res Photo";
            $creator = !empty($oItem['creator']) ? "by " . $oItem['creator'] : "Public Photo";
            $ext = strtoupper(pathinfo(parse_url($imgUrl, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'JPG');
            if (!in_array($ext, ['JPG', 'JPEG', 'PNG', 'WEBP', 'GIF', 'SVG'])) $ext = 'JPG';

            $w = $oItem['width'] ?? 0;
            $h = $oItem['height'] ?? 0;
            $dim = ($w && $h) ? "{$w}x{$h}" : "HD Quality";

            $items[] = [
                'id'           => 'ov_' . ($oItem['id'] ?? uniqid()),
                'title'        => $title,
                'category'     => 'Images & 4K',
                'file_type'    => $ext,
                'file_size'    => "Full HD • {$dim}",
                'description'  => "High Definition Public Media • {$creator} • Free Public License",
                'thumbnail'    => $thumbUrl,
                'direct_url'   => $imgUrl,
                'stream_url'   => $imgUrl,
                'preview_type' => 'image',
                'preview_url'  => $imgUrl,
                'source'       => parse_url($imgUrl, PHP_URL_HOST) ?: 'Openverse CDN'
            ];
            if (count($items) >= 14) break;
        }
    }

    return filterAndRankResults($cleanQuery, $items, 'image', 35);
}

/**
 * 5. Search Books & PDFs by Name (Direct PDF Downloads & Open Library)
 */
function searchDirectPdfsByName($query) {
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return [];

    $items = [];

    // A. Open Library Search API (Authoritative Books & Ebooks with Direct Archive.org PDFs)
    $olUrl = "https://openlibrary.org/search.json?q=" . urlencode($cleanQuery) . "&limit=6";
    $ch = curl_init($olUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlwaysDownloadApp/2.0');
    curl_setopt($ch, CURLOPT_TIMEOUT, 4);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $olRes = curl_exec($ch);
    curl_close($ch);

    if ($olRes) {
        $olData = json_decode($olRes, true);
        foreach ($olData['docs'] ?? [] as $doc) {
            $title = $doc['title'] ?? '';
            if (empty($title)) continue;
            $author = is_array($doc['author_name'] ?? null) ? implode(', ', array_slice($doc['author_name'], 0, 2)) : ($doc['author_name'] ?? 'Author');
            $cover = !empty($doc['cover_i']) ? "https://covers.openlibrary.org/b/id/{$doc['cover_i']}-M.jpg" : '';
            $iaIds = $doc['ia'] ?? [];
            $dlUrl = '';
            if (!empty($iaIds)) {
                $firstIa = $iaIds[0];
                $dlUrl = "https://archive.org/download/{$firstIa}/{$firstIa}.pdf";
            } else {
                $key = $doc['key'] ?? '';
                $dlUrl = "https://openlibrary.org{$key}";
            }

            $items[] = [
                'id'           => 'ol_' . md5($title . $author),
                'title'        => "{$title} (Official Book / PDF)",
                'category'     => 'PDF & Books',
                'file_type'    => 'PDF',
                'file_size'    => "Complete Edition • by {$author}",
                'description'  => "Author: {$author} • Verified Open Library / Internet Archive Public Edition",
                'thumbnail'    => $cover,
                'direct_url'   => $dlUrl,
                'stream_url'   => $dlUrl,
                'preview_type' => 'pdf',
                'preview_url'  => $dlUrl,
                'source'       => 'Open Library / Archive.org'
            ];
        }
    }

    // B. Internet Archive Books with tight Solr search
    $iaPdfs = searchArchiveOrgFast($cleanQuery, 'texts', ['pdf'], 'Book / PDF', 'PDF', 4);
    // C. Project Gutenberg for classical literature
    $gutenPdfs = searchGutenbergBooks($cleanQuery, 3);

    $merged = array_merge($items, $iaPdfs, $gutenPdfs);
    return filterAndRankResults($cleanQuery, $merged, 'pdf', 40);
}

/**
 * 6. Search Songs by Name (Direct MP3 & Audio Downloads)
 */
function searchDirectSongsByName($query) {
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return [];

    $iaSongs = searchArchiveOrgFast($cleanQuery, 'audio', ['mp3', 'flac', 'wav'], 'Song / MP3', 'MP3', 4);
    $ytSongs = searchYouTubeByName($cleanQuery, 3, 'Song / MP3');
    $merged = array_merge($iaSongs, $ytSongs);

    return filterAndRankResults($cleanQuery, $merged, 'song', 40);
}

/**
 * 7. Search Movies & Videos by Name (Direct Full HD / 1080p MP4 Downloads)
 */
function searchDirectMoviesByName($query) {
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return [];

    $iaMovies = searchArchiveOrgFast($cleanQuery, 'movies', ['mp4', 'mkv', 'avi', 'webm'], 'Movie / Video', 'MP4', 4);
    $ytMovies = searchYouTubeByName($cleanQuery . ' movie full hd', 3, 'Movie / Video');
    $merged = array_merge($iaMovies, $ytMovies);

    return filterAndRankResults($cleanQuery, $merged, 'movie', 40);
}

/**
 * 8. Search Games by Name (PC Installers, ROMs, ZIP)
 */
function searchDirectGamesByName($query) {
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return [];

    $iaGames = searchArchiveOrgFast($cleanQuery, 'software', ['zip', 'exe', 'iso', '7z', 'rar'], 'Game / PC', 'ZIP', 4);
    $ytGames = searchYouTubeByName($cleanQuery . ' pc game gameplay trailer', 2, 'Game Video / Trailer');
    $merged = array_merge($iaGames, $ytGames);

    return filterAndRankResults($cleanQuery, $merged, 'game', 40);
}

/**
 * 9. Search Code & Scripts by Name (Strictly Repositories & Code - No YouTube)
 */
function searchDirectCodeByName($query) {
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return [];

    $items = [];
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "&sort=stars&per_page=8";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlwaysDownloadApp/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    $repos = [];
    if ($res) {
        $data = json_decode($res, true);
        if (!isset($data['message']) || !str_contains(strtolower($data['message']), 'rate limit')) {
            $repos = $data['items'] ?? [];
        }
    }

    // Fallback if rate-limited: parse Bing site:github.com
    if (empty($repos)) {
        $bingGh = searchWebSearchEngine("site:github.com " . $cleanQuery, "ZIP", "Code & Script", "REPO", 6);
        foreach ($bingGh as $bItem) {
            $url = $bItem['direct_url'];
            if (preg_match('~github\.com/([a-zA-Z0-9_.-]+)/([a-zA-Z0-9_.-]+)~', $url, $m)) {
                $fullName = "{$m[1]}/{$m[2]}";
                $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/main.zip";
                $items[] = [
                    'id'           => 'code_bing_' . md5($fullName),
                    'title'        => "{$m[2]} (Complete Source Code .ZIP)",
                    'category'     => 'Code & Script',
                    'file_type'    => 'ZIP',
                    'file_size'    => "Source Repository Package",
                    'description'  => "Official Open Source Repository • Complete Code Archive",
                    'thumbnail'    => "https://github.githubassets.com/favicons/favicon.png",
                    'direct_url'   => $zipUrl,
                    'stream_url'   => $zipUrl,
                    'preview_type' => 'link',
                    'preview_url'  => "https://github.com/{$fullName}",
                    'source'       => "GitHub ({$fullName})"
                ];
            }
        }
    } else {
        foreach ($repos as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $defaultBranch = $repo['default_branch'] ?? 'main';
            $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/{$defaultBranch}.zip";
            $lang = $repo['language'] ?? 'Source';

            $items[] = [
                'id'           => 'code_gh_' . $repo['id'],
                'title'        => $repoName . " (Complete Source Code .ZIP)",
                'category'     => 'Code & Script',
                'file_type'    => 'ZIP',
                'file_size'    => "★ {$stars} Stars • {$lang}",
                'description'  => ($repo['description'] ?? 'Open source repository') . " • Language: {$lang}",
                'thumbnail'    => $repo['owner']['avatar_url'] ?? '',
                'direct_url'   => $zipUrl,
                'stream_url'   => $zipUrl,
                'preview_type' => 'link',
                'preview_url'  => "https://github.com/{$fullName}",
                'source'       => "GitHub ({$fullName})"
            ];
        }
    }

    return filterAndRankResults($cleanQuery, $items, 'code', 40);
}

/**
 * 10. Search Archives & Datasets by Name (Strictly Archives - No YouTube)
 */
function searchDirectArchivesByName($query) {
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return [];

    $items = [];

    // A. Internet Archive software & datasets for ZIP, 7Z, ISO, TAR, RAR
    $iaArchives = searchArchiveOrgFast($cleanQuery, 'software', ['zip', 'iso', '7z', 'rar', 'tar', 'gz'], 'Archive / ZIP', 'ZIP', 4);

    // B. GitHub releases and dataset repositories
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "&sort=stars&per_page=5";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlwaysDownloadApp/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        foreach ($data['items'] ?? [] as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $defaultBranch = $repo['default_branch'] ?? 'main';
            $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/{$defaultBranch}.zip";

            $items[] = [
                'id'           => 'arch_gh_' . $repo['id'],
                'title'        => "{$repoName} (Official Data / Archive .ZIP)",
                'category'     => 'Archive / ZIP',
                'file_type'    => 'ZIP',
                'file_size'    => "★ {$stars} Stars • Archive Package",
                'description'  => ($repo['description'] ?? 'Verified open dataset and files archive') . " • Direct ZIP",
                'thumbnail'    => $repo['owner']['avatar_url'] ?? '',
                'direct_url'   => $zipUrl,
                'stream_url'   => $zipUrl,
                'preview_type' => 'link',
                'preview_url'  => "https://github.com/{$fullName}",
                'source'       => "GitHub ({$fullName})"
            ];
        }
    }

    $merged = array_merge($iaArchives, $items);
    return filterAndRankResults($cleanQuery, $merged, 'archive', 38);
}

/**
 * 11. Search All Categories (Aggregated Fast Direct Downloads)
 */
function searchDirectAllByName($query) {
    $results = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return $results;

    // 1. Curated software check (instant)
    $curated = getCuratedSoftware($cleanQuery);
    if (!empty($curated)) {
        $results = array_merge($results, array_slice($curated, 0, 2));
    }

    // 2. GitHub Top Repositories (1 fast call, 2 items)
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "&sort=stars&per_page=3";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 2);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        foreach ($data['items'] ?? [] as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $defaultBranch = $repo['default_branch'] ?? 'main';
            $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/{$defaultBranch}.zip";
            $stars = number_format($repo['stargazers_count'] ?? 0);

            $results[] = [
                'id'           => 'all_gh_' . $repo['id'],
                'title'        => "{$repoName} (Official Source Package .ZIP)",
                'category'     => 'GitHub / Code',
                'file_type'    => 'ZIP',
                'file_size'    => "★ {$stars} Stars",
                'description'  => ($repo['description'] ?? 'Official Open Source Repository') . " • Direct Archive",
                'thumbnail'    => $repo['owner']['avatar_url'] ?? '',
                'direct_url'   => $zipUrl,
                'stream_url'   => $zipUrl,
                'preview_type' => 'link',
                'preview_url'  => "https://github.com/{$fullName}",
                'source'       => "GitHub ({$fullName})"
            ];
            if (count($results) >= 4) break;
        }
    }

    // 3. Internet Archive Media
    $iaResults = searchArchiveOrgFast($cleanQuery, 'movies', ['mp4', 'mkv'], 'Video / Media', 'MP4', 2);
    if (empty($iaResults)) {
        $iaResults = searchArchiveOrgFast($cleanQuery, 'software', ['zip', 'exe'], 'Software / Package', 'ZIP', 2);
    }
    $results = array_merge($results, $iaResults);

    // 4. Apple iTunes for iOS
    $itunesUrl = "https://itunes.apple.com/search?term=" . urlencode($cleanQuery) . "&entity=software&limit=2";
    $ch2 = curl_init($itunesUrl);
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_TIMEOUT, 2);
    curl_setopt($ch2, CURLOPT_USERAGENT, 'AlwaysDownloadApp/2.0');
    curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
    $itRes = curl_exec($ch2);
    curl_close($ch2);
    if ($itRes) {
        $itData = json_decode($itRes, true);
        foreach ($itData['results'] ?? [] as $app) {
            $name = $app['trackName'] ?? 'iOS App';
            $results[] = [
                'id'           => 'all_ios_' . ($app['trackId'] ?? uniqid()),
                'title'        => "{$name} (Official iOS App)",
                'category'     => 'iOS & IPA',
                'file_type'    => 'IPA',
                'file_size'    => 'Official Apple App Store Package',
                'description'  => "Official Apple App Store • " . ($app['genres'][0] ?? 'App'),
                'thumbnail'    => $app['artworkUrl512'] ?? ($app['artworkUrl100'] ?? ''),
                'direct_url'   => $app['trackViewUrl'] ?? '',
                'stream_url'   => $app['trackViewUrl'] ?? '',
                'preview_type' => 'link',
                'preview_url'  => $app['trackViewUrl'] ?? '',
                'source'       => 'Apple App Store'
            ];
        }
    }

    // 5. YouTube Media
    $ytResults = searchYouTubeByName($cleanQuery, 2, 'Media / Video');
    $results = array_merge($results, $ytResults);

    return filterAndRankResults($cleanQuery, $results, 'all', 40);
}

/**
 * High-Speed Parallel Archive.org File Matcher using curl_multi
 */
function searchArchiveOrgFast($titleQuery, $mediatype, $targetExts, $categoryLabel, $fileTypeLabel, $max = 4) {
    if (!is_array($targetExts)) {
        $targetExts = [$targetExts];
    }
    $targetExts = array_map('strtolower', $targetExts);

    $cleanQuery = preg_replace('/[^a-zA-Z0-9 ]/', ' ', $titleQuery);
    $cleanQuery = trim(preg_replace('/\s+/', ' ', $cleanQuery));
    if (empty($cleanQuery)) return [];

    $solrQ = 'title:(' . $cleanQuery . ') AND mediatype:' . $mediatype;
    $searchUrl = "https://archive.org/advancedsearch.php?q=" . urlencode($solrQ) . "&fl[]=identifier,title,creator,downloads,description&sort[]=downloads+desc&rows=" . ($max + 2) . "&output=json";

    $ch = curl_init($searchUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($res, true);
    $docs = $data['response']['docs'] ?? [];

    if (empty($docs)) {
        $solrQ = '(' . $cleanQuery . ') AND mediatype:' . $mediatype;
        $searchUrl = "https://archive.org/advancedsearch.php?q=" . urlencode($solrQ) . "&fl[]=identifier,title,creator,downloads,description&sort[]=downloads+desc&rows=" . ($max + 2) . "&output=json";
        $ch = curl_init($searchUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $res = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($res, true);
        $docs = $data['response']['docs'] ?? [];
    }

    if (empty($docs)) return [];

    $docsToScan = array_slice($docs, 0, min(count($docs), $max));

    $mh = curl_multi_init();
    $handles = [];

    foreach ($docsToScan as $doc) {
        $id = $doc['identifier'];
        $c = curl_init("https://archive.org/metadata/{$id}/files");
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_TIMEOUT, 3);
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
        curl_multi_add_handle($mh, $c);
        $handles[$id] = ['curl' => $c, 'doc' => $doc];
    }

    $running = null;
    do {
        curl_multi_exec($mh, $running);
        curl_multi_select($mh, 0.1);
    } while ($running > 0);

    $items = [];

    foreach ($handles as $id => $info) {
        $chHandle = $info['curl'];
        $doc = $info['doc'];
        $raw = curl_multi_getcontent($chHandle);
        curl_multi_remove_handle($mh, $chHandle);
        curl_close($chHandle);

        $fData = json_decode($raw, true);
        $files = $fData['result'] ?? [];
        if (empty($files)) continue;

        $title = $doc['title'] ?? $id;
        $author = is_array($doc['creator'] ?? '') ? implode(', ', $doc['creator']) : ($doc['creator'] ?? 'Public Archive');
        $downloads = isset($doc['downloads']) ? number_format($doc['downloads']) : null;

        $bestFile = null;
        $maxBytes = 0;

        foreach ($files as $f) {
            $name = $f['name'] ?? '';
            if (str_contains($name, '.thumbs/') || str_contains($name, '_thumb') || str_ends_with($name, '_meta.xml') || str_ends_with($name, '_files.xml')) {
                continue;
            }

            $fExt = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (in_array($fExt, $targetExts)) {
                $fSize = isset($f['size']) ? (float)$f['size'] : 0;
                $isHd = (!empty($f['height']) && (int)$f['height'] >= 720);
                if ($bestFile === null || $fSize > $maxBytes || $isHd) {
                    $bestFile = $f;
                    $maxBytes = $fSize;
                    if ($isHd && $fSize > 50000000) break;
                }
            }
        }

        if ($bestFile) {
            $name = $bestFile['name'];
            $fExt = strtoupper(pathinfo($name, PATHINFO_EXTENSION));
            $fileUrl = "https://archive.org/download/{$id}/" . rawurlencode($name);
            $bytes = isset($bestFile['size']) ? (float)$bestFile['size'] : 0;
            $sizeStr = $bytes > 0 ? formatBytesEng($bytes) : 'Direct File';

            $qualityLabel = '';
            if (!empty($bestFile['height'])) {
                $h = (int)$bestFile['height'];
                if ($h >= 1080) $qualityLabel = "Full HD 1080p • ";
                else if ($h >= 720) $qualityLabel = "HD 720p • ";
            } else if ($mediatype === 'movies' && $bytes > 400 * 1024 * 1024) {
                $qualityLabel = "Full HD/HQ • ";
            }

            $desc = "Creator: {$author}";
            if ($downloads) $desc .= " • ★ {$downloads} Downloads";
            $desc .= " • 100% Direct Public CDN Link";

            $previewType = 'link';
            if (in_array(strtolower($fExt), ['mp3', 'wav', 'flac'])) $previewType = 'audio';
            else if (in_array(strtolower($fExt), ['mp4', 'webm', 'mkv', 'avi'])) $previewType = 'video';
            else if (strtolower($fExt) === 'pdf') $previewType = 'pdf';

            $items[] = [
                'id'           => 'ia_' . md5($fileUrl),
                'title'        => $title,
                'category'     => $categoryLabel,
                'file_type'    => $fExt,
                'file_size'    => $qualityLabel . $sizeStr,
                'description'  => $desc,
                'thumbnail'    => "https://archive.org/services/img/{$id}",
                'direct_url'   => $fileUrl,
                'stream_url'   => $fileUrl,
                'preview_type' => $previewType,
                'preview_url'  => $fileUrl,
                'source'       => 'Internet Archive CDN'
            ];
        }
    }
    curl_multi_close($mh);
    return $items;
}

/**
 * Gutenberg Classical Literature Search
 */
function searchGutenbergBooks($query, $max = 3) {
    $gutenUrl = "https://gutendex.com/books/?search=" . urlencode($query);
    $ch = curl_init($gutenUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    $items = [];
    if (!$res) return $items;
    $data = json_decode($res, true);

    foreach ($data['results'] ?? [] as $book) {
        $bookId = $book['id'];
        $title = $book['title'];
        $author = !empty($book['authors']) ? $book['authors'][0]['name'] : 'Classical Author';
        $formats = $book['formats'] ?? [];
        $pdfUrl = $formats['application/pdf'] ?? $formats['application/epub+zip'] ?? "https://www.gutenberg.org/ebooks/{$bookId}.epub.images";
        $thumb = $formats['image/jpeg'] ?? "https://www.gutenberg.org/cache/epub/{$bookId}/pg{$bookId}.cover.medium.jpg";
        $ext = str_contains($pdfUrl, 'pdf') ? 'PDF' : 'EPUB';

        $items[] = [
            'id'           => 'guten_' . $bookId,
            'title'        => $title,
            'category'     => 'Book / Literature',
            'file_type'    => $ext,
            'file_size'    => 'Complete eBook',
            'description'  => "Author: {$author} • Project Gutenberg Classical Literature",
            'thumbnail'    => $thumb,
            'direct_url'   => $pdfUrl,
            'stream_url'   => $pdfUrl,
            'preview_type' => 'link',
            'preview_url'  => "https://www.gutenberg.org/ebooks/{$bookId}",
            'source'       => 'Project Gutenberg'
        ];
        if (count($items) >= $max) break;
    }
    return $items;
}

/**
 * Bing Web Search Engine Scraper (Unpacks Base64 Destination URLs)
 */
function searchWebSearchEngine($query, $ext, $categoryName, $fileTypeLabel, $max = 3) {
    $clean = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($clean)) return [];

    $url = "https://www.bing.com/search?q=" . urlencode("{$clean} download") . "&setlang=en-us";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $html = curl_exec($ch);
    curl_close($ch);

    $items = [];
    if (!$html) return $items;

    if (preg_match_all('/<li class="b_algo"[^>]*>.*?<h2[^>]*><a[^>]+href="([^"]+)"[^>]*>(.*?)<\/a><\/h2>/is', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $rawUrl = html_entity_decode($m[1]);
            $title = strip_tags($m[2]);
            $realUrl = $rawUrl;
            if (preg_match('/[?&]u=a1([a-zA-Z0-9_\-]+)/', $rawUrl, $u)) {
                $padded = strtr($u[1], '-_', '+/');
                $padded .= str_repeat('=', (4 - strlen($padded) % 4) % 4);
                $decoded = base64_decode($padded);
                if ($decoded && filter_var($decoded, FILTER_VALIDATE_URL)) {
                    $realUrl = $decoded;
                }
            }

            if (str_contains($realUrl, 'bing.com') || str_contains($realUrl, 'microsoft.com/en-us/search')) {
                continue;
            }

            $items[] = [
                'id'           => 'web_' . md5($realUrl),
                'title'        => $title,
                'category'     => $categoryName,
                'file_type'    => strtoupper($ext),
                'file_size'    => 'Public Web Download',
                'description'  => "Public Web File • Direct Download Link",
                'thumbnail'    => '',
                'direct_url'   => $realUrl,
                'stream_url'   => $realUrl,
                'preview_type' => 'link',
                'preview_url'  => $realUrl,
                'source'       => parse_url($realUrl, PHP_URL_HOST) ?: 'Public Web'
            ];

            if (count($items) >= $max) break;
        }
    }
    return $items;
}

/**
 * Fast YouTube Search & Media Outcomes Engine via lightweight cURL
 */
function searchYouTubeByName($query, $max = 3, $preferredCategory = 'Video') {
    $items = [];
    $cleanQuery = preg_replace('/[^\p{L}\p{N}\s\-_]/u', ' ', $query);
    $cleanQuery = trim(preg_replace('/\s+/', ' ', $cleanQuery));
    if (empty($cleanQuery)) return $items;

    $url = "https://www.youtube.com/results?search_query=" . urlencode($cleanQuery);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $html = curl_exec($ch);
    curl_close($ch);

    if ($html && preg_match('/var ytInitialData = ({.*?});<\/script>/s', $html, $m)) {
        $data = json_decode($m[1], true);
        $contents = $data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'] ?? [];
        foreach ($contents as $entry) {
            $v = $entry['videoRenderer'] ?? null;
            if (!$v) continue;
            $id = $v['videoId'] ?? '';
            if (empty($id)) continue;

            $title = $v['title']['runs'][0]['text'] ?? 'YouTube Media';
            $duration = $v['lengthText']['simpleText'] ?? 'HD';
            $thumb = "https://i.ytimg.com/vi/{$id}/hqdefault.jpg";
            $isAudioPreferred = ($preferredCategory === 'Song / MP3');

            $directWatch = "https://www.youtube.com/watch?v={$id}";
            $externalDl = "https://www.ssyoutube.com/watch?v={$id}";
            $fileType = $isAudioPreferred ? 'MP3' : 'MP4';
            $sizeLabel = $isAudioPreferred ? "Duration: {$duration} • 320kbps Audio" : "Duration: {$duration} • Full HD / 720p";

            $items[] = [
                'id'           => 'yt_' . $id,
                'title'        => $title,
                'category'     => $preferredCategory,
                'file_type'    => $fileType,
                'file_size'    => $sizeLabel,
                'description'  => "Real Public Media • Direct 1-Click Download • No Waiting",
                'thumbnail'    => $thumb,
                'direct_url'   => $externalDl,
                'stream_url'   => $externalDl,
                'watch_url'    => $directWatch,
                'preview_type' => 'video',
                'preview_url'  => "https://www.youtube.com/embed/{$id}?autoplay=1",
                'source'       => 'Public Stream CDN'
            ];
            if (count($items) >= $max) break;
        }
    }

    return $items;
}

function formatBytesEng($bytes, $precision = 2) {
    $bytes = (float)$bytes;
    if ($bytes <= 0) return 'Direct File';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $pow = floor(log($bytes) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}
