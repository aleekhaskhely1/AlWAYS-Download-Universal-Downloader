<?php
/**
 * Always Download - Instant Direct Public Search Engine
 * Search by NAME for GitHub, Softwares, Images & 4K, Songs, Movies, Books/PDFs, Games, Code, and Archives
 * Delivers 100% real direct downloads (No URL pasting required by user)
 */

require_once __DIR__ . '/../config/db.php';

// Release session lock immediately to allow fast, non-blocking concurrent searches
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
}

$query    = trim($_GET['q'] ?? '');
$category = strtolower(trim($_GET['category'] ?? 'all'));

if (empty($query)) {
    jsonResponse(false, 'Please enter a name to search.');
}

// If user happens to paste a direct URL, route to direct URL inspector
if (preg_match('~^(?:f|ht)tps?://~i', $query)) {
    header("Location: direct_url.php?url=" . urlencode($query));
    exit;
}

$results = [];

switch ($category) {
    case 'github':
    case 'git':
    case 'repo':
        $results = searchDirectGitHubByName($query);
        break;

    case 'software':
    case 'softwares':
    case 'exe':
    case 'app':
    case 'apps':
        $results = searchDirectAllSoftwaresByName($query);
        break;

    case 'image':
    case 'images':
    case 'wallpaper':
    case 'wallpapers':
    case 'photo':
        $results = searchDirectImagesByName($query);
        break;

    case 'song':
    case 'mp3':
    case 'audio':
    case 'music':
        $results = searchDirectSongsByName($query);
        break;

    case 'movie':
    case 'video':
    case 'film':
        $results = searchDirectMoviesByName($query);
        break;

    case 'pdf':
    case 'book':
    case 'books':
    case 'document':
        $results = searchDirectPdfsByName($query);
        break;

    case 'game':
    case 'games':
    case 'rom':
        $results = searchDirectGamesByName($query);
        break;

    case 'code':
    case 'text':
    case 'script':
        $results = searchDirectCodeByName($query);
        break;

    case 'archive':
    case 'zip':
    case 'rar':
    case '7z':
        $results = searchDirectArchivesByName($query);
        break;

    case 'all':
    default:
        $results = searchDirectAllByName($query);
        break;
}

// Universal resilient fallback: if 0 results, broaden search across Archive.org & GitHub
if (empty($results)) {
    $results = searchArchiveOrgFast($query, 'texts', ['pdf'], 'Book / PDF', 'PDF', 3);
    if (empty($results)) {
        $results = searchDirectGitHubByName($query);
    }
    if (empty($results)) {
        $results = searchWebSearchEngine($query, 'exe', 'Public File', 'FILE', 3);
    }
}

jsonResponse(true, count($results) . " direct download results found!", [
    'query'    => $query,
    'category' => $category,
    'count'    => count($results),
    'results'  => $results
]);

/**
 * Curated Top Software Official Direct CDN Library
 * Provides instant (<0.01s), 100% working verified official installers for popular software
 */
function getCuratedSoftware($query) {
    $catalog = [
        'vlc' => [
            'name' => 'VLC Media Player (Official 64-bit Windows Installer)',
            'type' => 'EXE',
            'size' => '42.3 MB • Official Release',
            'url'  => 'https://get.videolan.org/vlc/3.0.21/win64/vlc-3.0.21-win64.exe',
            'desc' => 'Official VideoLAN Open-Source Cross-Platform Media Player for Windows',
            'thumb'=> 'https://images.videolan.org/images/icons-VLC/vlc.mini.svg'
        ],
        '7-zip' => [
            'name' => '7-Zip High-Ratio Archive Manager (Official 64-bit)',
            'type' => 'EXE',
            'size' => '1.5 MB • Official Installer',
            'url'  => 'https://www.7-zip.org/a/7z2409-x64.exe',
            'desc' => 'Free and Open Source File Archiver with high compression ratio',
            'thumb'=> 'https://www.7-zip.org/7ziplogo.png'
        ],
        '7zip' => [
            'name' => '7-Zip High-Ratio Archive Manager (Official 64-bit)',
            'type' => 'EXE',
            'size' => '1.5 MB • Official Installer',
            'url'  => 'https://www.7-zip.org/a/7z2409-x64.exe',
            'desc' => 'Free and Open Source File Archiver with high compression ratio',
            'thumb'=> 'https://www.7-zip.org/7ziplogo.png'
        ],
        'notepad++' => [
            'name' => 'Notepad++ Source Code Editor (Official x64 Installer)',
            'type' => 'EXE',
            'size' => '4.6 MB • Official Release',
            'url'  => 'https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.7.7/npp.8.7.7.Installer.x64.exe',
            'desc' => 'Free source code editor and Notepad replacement supporting multiple languages',
            'thumb'=> 'https://notepad-plus-plus.org/assets/images/nppHeroImage.png'
        ],
        'notepad' => [
            'name' => 'Notepad++ Source Code Editor (Official x64 Installer)',
            'type' => 'EXE',
            'size' => '4.6 MB • Official Release',
            'url'  => 'https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.7.7/npp.8.7.7.Installer.x64.exe',
            'desc' => 'Free source code editor and Notepad replacement supporting multiple languages',
            'thumb'=> 'https://notepad-plus-plus.org/assets/images/nppHeroImage.png'
        ],
        'blender' => [
            'name' => 'Blender 3D Suite (Official Windows MSI Installer)',
            'type' => 'MSI',
            'size' => '348 MB • Official Installer',
            'url'  => 'https://download.blender.org/release/Blender4.3/blender-4.3.2-windows-x64.msi',
            'desc' => 'Open Source 3D Creation Suite: Modeling, Rigging, Animation, Simulation, Rendering',
            'thumb'=> 'https://download.blender.org/branding/blender_logo_socket.png'
        ],
        'obs' => [
            'name' => 'OBS Studio (Open Broadcaster Software Windows Installer)',
            'type' => 'EXE',
            'size' => '130 MB • Official Release',
            'url'  => 'https://github.com/obsproject/obs-studio/releases/download/31.0.2/OBS-Studio-31.0.2-Windows-Installer.exe',
            'desc' => 'Free and open source software for video recording and live streaming',
            'thumb'=> 'https://obsproject.com/assets/images/logo.png'
        ],
        'vscode' => [
            'name' => 'Visual Studio Code (Microsoft Official Windows x64 User Installer)',
            'type' => 'EXE',
            'size' => '94 MB • Official Microsoft CDN',
            'url'  => 'https://update.code.visualstudio.com/latest/win32-x64-user/stable',
            'desc' => 'Code editing redefined. Free, built on open source, runs everywhere',
            'thumb'=> 'https://code.visualstudio.com/favicon.ico'
        ],
        'visual studio code' => [
            'name' => 'Visual Studio Code (Microsoft Official Windows x64 User Installer)',
            'type' => 'EXE',
            'size' => '94 MB • Official Microsoft CDN',
            'url'  => 'https://update.code.visualstudio.com/latest/win32-x64-user/stable',
            'desc' => 'Code editing redefined. Free, built on open source, runs everywhere',
            'thumb'=> 'https://code.visualstudio.com/favicon.ico'
        ],
        'git' => [
            'name' => 'Git for Windows (Official 64-bit Standalone Installer)',
            'type' => 'EXE',
            'size' => '64 MB • Official Release',
            'url'  => 'https://github.com/git-for-windows/git/releases/download/v2.48.1.windows.1/Git-2.48.1-64-bit.exe',
            'desc' => 'Fast, scalable, distributed revision control system with Git BASH and GUI',
            'thumb'=> 'https://git-scm.com/images/logos/downloads/Git-Icon-1788C.png'
        ],
        'chrome' => [
            'name' => 'Google Chrome (Official Windows 64-bit Standalone Offline Installer)',
            'type' => 'EXE',
            'size' => '102 MB • Direct Google CDN',
            'url'  => 'https://dl.google.com/chrome/install/standalone/win64/ChromeStandaloneSetup64.exe',
            'desc' => 'Fast, secure, and free web browser built by Google for modern internet',
            'thumb'=> 'https://www.google.com/chrome/static/images/chrome-logo.svg'
        ],
        'firefox' => [
            'name' => 'Mozilla Firefox (Official Windows 64-bit Offline Installer)',
            'type' => 'EXE',
            'size' => '58 MB • Official Mozilla CDN',
            'url'  => 'https://download.mozilla.org/?product=firefox-latest-ssl&os=win64&lang=en-US',
            'desc' => 'Fast, private and safe web browser by Mozilla for Windows 64-bit',
            'thumb'=> 'https://www.mozilla.org/media/protocol/img/logos/firefox/browser/logo.eb1324e44442.svg'
        ],
        'rufus' => [
            'name' => 'Rufus (Create Bootable USB Drives - Portable EXE)',
            'type' => 'EXE',
            'size' => '1.7 MB • Official Release',
            'url'  => 'https://github.com/pbatard/rufus/releases/download/v4.6/rufus-4.6.exe',
            'desc' => 'The reliable USB formatting and bootable drive creation utility',
            'thumb'=> 'https://rufus.ie/pics/rufus-128.png'
        ],
        'handbrake' => [
            'name' => 'HandBrake Open Source Video Transcoder (x64 Installer)',
            'type' => 'EXE',
            'size' => '24.5 MB • Official Release',
            'url'  => 'https://github.com/HandBrake/HandBrake/releases/download/1.9.1/HandBrake-1.9.1-x86_64-Win_GUI.exe',
            'desc' => 'The open source video transcoder to convert video from nearly any format',
            'thumb'=> 'https://handbrake.fr/img/logo.png'
        ],
        'filezilla' => [
            'name' => 'FileZilla Client (Official 64-bit Windows Installer)',
            'type' => 'EXE',
            'size' => '12.8 MB • Official Release',
            'url'  => 'https://download.filezilla-project.org/client/FileZilla_3.68.1_win64-setup.exe',
            'desc' => 'The free FTP, FTPS and SFTP cross-platform client with intuitive GUI',
            'thumb'=> 'https://filezilla-project.org/images/logo.png'
        ],
        'audacity' => [
            'name' => 'Audacity Multi-track Audio Editor (Official Windows 64-bit)',
            'type' => 'EXE',
            'size' => '32.1 MB • Official Release',
            'url'  => 'https://github.com/audacity/audacity/releases/download/Audacity-3.7.1/audacity-win-3.7.1-64bit.exe',
            'desc' => 'Free, open source, cross-platform audio software for multi-track recording',
            'thumb'=> 'https://www.audacityteam.org/wp-content/themes/audacity/img/audacity_logo_header.png'
        ],
        'kodi' => [
            'name' => 'Kodi Home Theater & Media Hub (Windows 64-bit Installer)',
            'type' => 'EXE',
            'size' => '78.5 MB • Official Kodi Mirror',
            'url'  => 'https://mirrors.kodi.tv/releases/windows/win64/kodi-21.2-Omega-x64.exe',
            'desc' => 'Ultimate entertainment center for music, movies, photos and live TV',
            'thumb'=> 'https://kodi.tv/images/kodi-logo.svg'
        ],
        'cpuz' => [
            'name' => 'CPU-Z Hardware Information & Benchmarking Tool',
            'type' => 'EXE',
            'size' => '3.4 MB • Official Release',
            'url'  => 'https://download.cpuid.com/cpu-z/cpu-z_2.13-en.exe',
            'desc' => 'Gathers information on the main devices of your system (CPU, Cache, Mainboard)',
            'thumb'=> 'https://www.cpuid.com/medias/images/icon-cpuz.png'
        ],
        'anydesk' => [
            'name' => 'AnyDesk Remote Desktop Software (Standalone EXE)',
            'type' => 'EXE',
            'size' => '4.8 MB • Official AnyDesk CDN',
            'url'  => 'https://download.anydesk.com/AnyDesk.exe',
            'desc' => 'Secure remote desktop software for fast internet connection and file transfer',
            'thumb'=> 'https://anydesk.com/assets/img/logos/anydesk-logo-icon.svg'
        ],
        'sumatra' => [
            'name' => 'SumatraPDF Fast & Lightweight PDF/eBook Reader',
            'type' => 'EXE',
            'size' => '7.8 MB • Official Installer',
            'url'  => 'https://www.sumatrapdfreader.org/dl/SumatraPDF-3.5.2-64-install.exe',
            'desc' => 'Free, lightweight and portable PDF, eBook (ePub, Mobi), XPS, DjVu, CHM reader',
            'thumb'=> 'https://www.sumatrapdfreader.org/favicon.ico'
        ]
    ];

    $matches = [];
    $qLower = strtolower(trim($query));
    foreach ($catalog as $key => $app) {
        if (str_contains($qLower, $key) || str_contains($key, $qLower)) {
            $matches[] = [
                'id'           => 'curated_' . $key,
                'title'        => $app['name'],
                'category'     => 'All Softwares',
                'file_type'    => $app['type'],
                'file_size'    => $app['size'],
                'description'  => $app['desc'] . ' • 100% Direct Official Installer',
                'thumbnail'    => $app['thumb'],
                'direct_url'   => $app['url'],
                'stream_url'   => $app['url'],
                'preview_type' => 'link',
                'preview_url'  => $app['url'],
                'source'       => 'Official Software Vendor CDN'
            ];
        }
    }
    return $matches;
}

/**
 * 1. Search GitHub Repositories & Binary Releases
 */
function searchDirectGitHubByName($query) {
    $items = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return $items;

    // Query GitHub Search API for Top Repositories
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "&sort=stars&per_page=8";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        $repos = $data['items'] ?? [];

        // Parallel inspect release assets for top 4 repos
        $mh = curl_multi_init();
        $handles = [];
        $inspectCount = min(count($repos), 4);

        for ($i = 0; $i < $inspectCount; $i++) {
            $fullName = $repos[$i]['full_name'];
            $relUrl = "https://api.github.com/repos/{$fullName}/releases/latest";
            $chRel = curl_init($relUrl);
            curl_setopt($chRel, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($chRel, CURLOPT_TIMEOUT, 2);
            curl_setopt($chRel, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
            curl_setopt($chRel, CURLOPT_SSL_VERIFYPEER, false);
            curl_multi_add_handle($mh, $chRel);
            $handles[$fullName] = $chRel;
        }

        $running = null;
        do {
            curl_multi_exec($mh, $running);
            curl_multi_select($mh, 0.1);
        } while ($running > 0);

        $releasesMap = [];
        foreach ($handles as $fullName => $chRel) {
            $relRaw = curl_multi_getcontent($chRel);
            curl_multi_remove_handle($mh, $chRel);
            curl_close($chRel);
            if ($relRaw) {
                $releasesMap[$fullName] = json_decode($relRaw, true);
            }
        }
        curl_multi_close($mh);

        foreach ($repos as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $desc = $repo['description'] ?? 'Official Open Source GitHub Repository';
            $avatar = $repo['owner']['avatar_url'] ?? 'https://github.githubassets.com/favicons/favicon.png';
            $defaultBranch = $repo['default_branch'] ?? 'main';
            $language = $repo['language'] ?? 'Source Code';
            $repoUrl = $repo['html_url'] ?? "https://github.com/{$fullName}";

            // Check if release binary found
            $relData = $releasesMap[$fullName] ?? null;
            if ($relData && !empty($relData['assets'])) {
                $tag = $relData['tag_name'] ?? 'latest';
                foreach ($relData['assets'] as $asset) {
                    $assetName = $asset['name'] ?? '';
                    $ext = strtolower(pathinfo($assetName, PATHINFO_EXTENSION));
                    if (in_array($ext, ['exe', 'msi', 'zip', 'dmg', 'pkg', 'apk', 'deb', 'appimage', 'gz'])) {
                        $dlUrl = $asset['browser_download_url'];
                        $size = isset($asset['size']) ? formatBytesEng($asset['size']) : 'Official Release';
                        $typeLabel = strtoupper($ext);
                        if ($typeLabel === 'GZ') $typeLabel = 'TAR.GZ';

                        $items[] = [
                            'id'           => 'gh_rel_' . ($asset['id'] ?? uniqid()),
                            'title'        => "{$repoName} ({$tag}) - {$assetName}",
                            'category'     => 'GitHub Release',
                            'file_type'    => $typeLabel,
                            'file_size'    => $size,
                            'description'  => "Official Binary Release • ★ {$stars} Stars • {$desc}",
                            'thumbnail'    => $avatar,
                            'direct_url'   => $dlUrl,
                            'stream_url'   => $dlUrl,
                            'preview_type' => 'link',
                            'preview_url'  => $repoUrl,
                            'source'       => "GitHub Releases ({$fullName})"
                        ];
                        break;
                    }
                }
            }

            // Always add direct source code .ZIP download for the repository
            $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/{$defaultBranch}.zip";
            $items[] = [
                'id'           => 'gh_repo_' . $repo['id'],
                'title'        => "{$repoName} (Complete Source Code .ZIP)",
                'category'     => 'GitHub Repo',
                'file_type'    => 'REPO',
                'file_size'    => "★ {$stars} Stars • {$language}",
                'description'  => "Official Repository Package • {$desc}",
                'thumbnail'    => $avatar,
                'direct_url'   => $zipUrl,
                'stream_url'   => $zipUrl,
                'preview_type' => 'link',
                'preview_url'  => $repoUrl,
                'source'       => "GitHub ({$fullName})"
            ];

            if (count($items) >= 10) break;
        }
    }

    return $items;
}

/**
 * 2. Search All Softwares (Windows EXE/MSI, Mac DMG, Android APK, Linux AppImage)
 */
function searchDirectAllSoftwaresByName($query) {
    $items = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return $items;

    // A. Check curated catalog for instant official downloads
    $curated = getCuratedSoftware($cleanQuery);
    if (!empty($curated)) {
        $items = array_merge($items, $curated);
    }

    // B. Search GitHub for multi-platform binaries (.exe, .msi, .dmg, .apk, .deb, .appimage, .zip)
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "+in:name,description&sort=stars&per_page=6";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        $repos = $data['items'] ?? [];

        // Parallel inspect release assets for repos
        $mh = curl_multi_init();
        $handles = [];
        $inspectCount = min(count($repos), 4);

        for ($i = 0; $i < $inspectCount; $i++) {
            $fullName = $repos[$i]['full_name'];
            $relUrl = "https://api.github.com/repos/{$fullName}/releases/latest";
            $chRel = curl_init($relUrl);
            curl_setopt($chRel, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($chRel, CURLOPT_TIMEOUT, 2);
            curl_setopt($chRel, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
            curl_setopt($chRel, CURLOPT_SSL_VERIFYPEER, false);
            curl_multi_add_handle($mh, $chRel);
            $handles[$fullName] = $chRel;
        }

        $running = null;
        do {
            curl_multi_exec($mh, $running);
            curl_multi_select($mh, 0.1);
        } while ($running > 0);

        $releasesMap = [];
        foreach ($handles as $fullName => $chRel) {
            $relRaw = curl_multi_getcontent($chRel);
            curl_multi_remove_handle($mh, $chRel);
            curl_close($chRel);
            if ($relRaw) {
                $releasesMap[$fullName] = json_decode($relRaw, true);
            }
        }
        curl_multi_close($mh);

        foreach ($repos as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $desc = $repo['description'] ?? 'Official Software Release';
            $avatar = $repo['owner']['avatar_url'] ?? '';
            $defaultBranch = $repo['default_branch'] ?? 'main';

            $relData = $releasesMap[$fullName] ?? null;
            $assetCount = 0;

            if ($relData && !empty($relData['assets'])) {
                $tag = $relData['tag_name'] ?? 'latest';
                foreach ($relData['assets'] as $asset) {
                    $assetName = $asset['name'] ?? '';
                    $ext = strtolower(pathinfo($assetName, PATHINFO_EXTENSION));
                    if (in_array($ext, ['exe', 'msi', 'zip', 'dmg', 'pkg', 'apk', 'deb', 'appimage'])) {
                        $dlUrl = $asset['browser_download_url'];
                        $size = isset($asset['size']) ? formatBytesEng($asset['size']) : 'Binary Release';

                        $osBadge = 'PC / All';
                        if (in_array($ext, ['exe', 'msi'])) $osBadge = 'Windows';
                        else if (in_array($ext, ['dmg', 'pkg'])) $osBadge = 'macOS';
                        else if (in_array($ext, ['apk'])) $osBadge = 'Android';
                        else if (in_array($ext, ['deb', 'appimage'])) $osBadge = 'Linux';

                        $items[] = [
                            'id'           => 'soft_gh_' . ($asset['id'] ?? uniqid()),
                            'title'        => "{$repoName} ({$osBadge}) - {$assetName}",
                            'category'     => 'All Softwares',
                            'file_type'    => strtoupper($ext),
                            'file_size'    => "{$osBadge} • {$size}",
                            'description'  => "Official Binary Release ({$tag}) • ★ {$stars} Stars • {$desc}",
                            'thumbnail'    => $avatar,
                            'direct_url'   => $dlUrl,
                            'stream_url'   => $dlUrl,
                            'preview_type' => 'link',
                            'preview_url'  => "https://github.com/{$fullName}",
                            'source'       => "GitHub Official ({$fullName})"
                        ];
                        $assetCount++;
                        if ($assetCount >= 2) break;
                    }
                }
            }

            if ($assetCount === 0) {
                $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/{$defaultBranch}.zip";
                $items[] = [
                    'id'           => 'soft_repo_' . $repo['id'],
                    'title'        => "{$repoName} (Official Setup Package)",
                    'category'     => 'All Softwares',
                    'file_type'    => 'ZIP',
                    'file_size'    => "★ {$stars} Stars",
                    'description'  => "Official Project & Tools • {$desc}",
                    'thumbnail'    => $avatar,
                    'direct_url'   => $zipUrl,
                    'stream_url'   => $zipUrl,
                    'preview_type' => 'link',
                    'preview_url'  => "https://github.com/{$fullName}",
                    'source'       => 'GitHub Open Source'
                ];
            }
            if (count($items) >= 6) break;
        }
    }

    // C. Parallel Archive.org search for PC software & tools (ISOs, EXE, ZIP)
    $iaSoftware = searchArchiveOrgFast($cleanQuery, 'software', ['exe', 'msi', 'zip', 'iso', 'apk', 'dmg'], 'All Softwares', 'EXE', 3);
    $items = array_merge($items, $iaSoftware);

    // D. YouTube software overview / tutorial
    $ytSoft = searchYouTubeByName($cleanQuery . ' software download installation', 1, 'Software Tutorial');
    $items = array_merge($items, $ytSoft);

    return $items;
}

function searchDirectSoftwareByName($query) {
    return searchDirectAllSoftwaresByName($query);
}

/**
 * 3. Search High-Definition Images & 4K Wallpapers
 */
function searchDirectImagesByName($query) {
    $items = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_]/u', ' ', $query));
    if (empty($cleanQuery)) return $items;

    // A. Wallhaven 4K/8K Ultra HD Wallpapers API
    $whUrl = "https://wallhaven.cc/api/v1/search?q=" . urlencode($cleanQuery) . "&categories=111&purity=100&sorting=relevance";
    $ch = curl_init($whUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $whRes = curl_exec($ch);
    curl_close($ch);

    if ($whRes) {
        $whData = json_decode($whRes, true);
        foreach ($whData['data'] ?? [] as $wItem) {
            $imgUrl = $wItem['path'] ?? '';
            if (empty($imgUrl)) continue;
            $thumbUrl = $wItem['thumbs']['original'] ?? ($wItem['thumbs']['small'] ?? $imgUrl);
            $resolution = $wItem['resolution'] ?? 'HD';
            $fileSize = isset($wItem['file_size']) ? formatBytesEng($wItem['file_size']) : '4K Image';
            $ext = strtoupper(pathinfo(parse_url($imgUrl, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'JPG');

            $qualityBadge = "{$resolution} • {$fileSize}";
            if (str_contains($resolution, '3840x') || str_contains($resolution, '7680x')) {
                $qualityBadge = "4K/8K UHD • " . $qualityBadge;
            } else if (str_contains($resolution, '1920x')) {
                $qualityBadge = "1080p FHD • " . $qualityBadge;
            }

            $items[] = [
                'id'           => 'wh_' . ($wItem['id'] ?? uniqid()),
                'title'        => "{$cleanQuery} HD Wallpaper (" . ($wItem['id'] ?? 'Ultra') . ")",
                'category'     => 'Images & 4K',
                'file_type'    => $ext,
                'file_size'    => $qualityBadge,
                'description'  => "Ultra High Resolution 4K/8K • Wallhaven Verified Direct CDN",
                'thumbnail'    => $thumbUrl,
                'direct_url'   => $imgUrl,
                'stream_url'   => $imgUrl,
                'preview_type' => 'image',
                'preview_url'  => $imgUrl,
                'source'       => 'Wallhaven 4K CDN'
            ];
            if (count($items) >= 8) break;
        }
    }

    // B. Openverse Public Images API (700M+ Creative Commons, Flickr & Web public images)
    $ovUrl = "https://api.openverse.org/v1/images/?q=" . urlencode($cleanQuery) . "&page_size=8";
    $ch = curl_init($ovUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $ovRes = curl_exec($ch);
    curl_close($ch);

    if ($ovRes) {
        $ovData = json_decode($ovRes, true);
        foreach ($ovData['results'] ?? [] as $oItem) {
            $imgUrl = $oItem['url'] ?? '';
            if (empty($imgUrl)) continue;
            $thumbUrl = $oItem['thumbnail'] ?? $imgUrl;
            $title = !empty($oItem['title']) ? $oItem['title'] : "{$cleanQuery} High-Res Photo";
            $creator = !empty($oItem['creator']) ? "by " . $oItem['creator'] : "Public Photo";
            $ext = strtoupper(pathinfo(parse_url($imgUrl, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'JPG');
            if (!in_array($ext, ['JPG', 'JPEG', 'PNG', 'WEBP', 'GIF', 'SVG'])) $ext = 'JPG';

            $w = $oItem['width'] ?? 0;
            $h = $oItem['height'] ?? 0;
            $dim = ($w && $h) ? "{$w}x{$h}" : "HD Quality";

            $items[] = [
                'id'           => 'ov_' . ($oItem['id'] ?? uniqid()),
                'title'        => $title,
                'category'     => 'Images & 4K',
                'file_type'    => $ext,
                'file_size'    => "Full HD • {$dim}",
                'description'  => "High Definition Public Media • {$creator} • Free Public License",
                'thumbnail'    => $thumbUrl,
                'direct_url'   => $imgUrl,
                'stream_url'   => $imgUrl,
                'preview_type' => 'image',
                'preview_url'  => $imgUrl,
                'source'       => parse_url($imgUrl, PHP_URL_HOST) ?: 'Openverse CDN'
            ];
            if (count($items) >= 14) break;
        }
    }

    // C. Wikimedia Commons API
    $wikiUrl = "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=" . urlencode($cleanQuery) . "&gsrlimit=4&prop=imageinfo&iiprop=url|size|mime&format=json";
    $ch = curl_init($wikiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 2);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $wikiRes = curl_exec($ch);
    curl_close($ch);

    if ($wikiRes) {
        $wikiData = json_decode($wikiRes, true);
        foreach ($wikiData['query']['pages'] ?? [] as $page) {
            $info = $page['imageinfo'][0] ?? null;
            if (!$info || empty($info['url'])) continue;
            $rawTitle = str_replace('File:', '', $page['title'] ?? 'High Resolution Image');
            $url = $info['url'];
            $ext = strtoupper(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'JPG');
            $size = isset($info['size']) ? formatBytesEng($info['size']) : 'HD Image';

            $items[] = [
                'id'           => 'wiki_' . ($page['pageid'] ?? uniqid()),
                'title'        => $rawTitle,
                'category'     => 'Images & 4K',
                'file_type'    => $ext,
                'file_size'    => "Wikimedia HD • {$size}",
                'description'  => "High Definition Public Domain Media • Direct Wikimedia CDN",
                'thumbnail'    => $url,
                'direct_url'   => $url,
                'stream_url'   => $url,
                'preview_type' => 'image',
                'preview_url'  => $url,
                'source'       => 'Wikimedia Commons'
            ];
            if (count($items) >= 18) break;
        }
    }

    return $items;
}

/**
 * 4. Search Books & PDFs by Name (Direct PDF Downloads)
 */
function searchDirectPdfsByName($query) {
    // A. Search Archive.org texts library with parallel file scanning
    $iaPdfs = searchArchiveOrgFast($query, 'texts', ['pdf'], 'Book / PDF', 'PDF', 4);

    // B. Search Gutenberg API for classical literature
    $gutenPdfs = searchGutenbergBooks($query, 3);

    return array_merge($iaPdfs, $gutenPdfs);
}

/**
 * 5. Search Songs by Name (Direct MP3 & Audio Downloads)
 */
function searchDirectSongsByName($query) {
    // A. Search Archive.org high-quality audio files
    $iaSongs = searchArchiveOrgFast($query, 'audio', ['mp3', 'flac', 'wav'], 'Song / MP3', 'MP3', 4);

    // B. Query YouTube for real audio outcomes
    $ytSongs = searchYouTubeByName($query, 3, 'Song / MP3');

    return array_merge($iaSongs, $ytSongs);
}

/**
 * 6. Search Movies & Videos by Name (Direct Full HD / 1080p MP4 Downloads)
 */
function searchDirectMoviesByName($query) {
    // A. Search Archive.org public feature films & Full HD movies (1080p / 720p MP4)
    $iaMovies = searchArchiveOrgFast($query, 'movies', ['mp4', 'mkv', 'avi', 'webm'], 'Movie / Video', 'MP4', 4);

    // B. YouTube HD video outcomes / full media
    $ytMovies = searchYouTubeByName($query . ' movie full hd', 3, 'Movie / Video');

    return array_merge($iaMovies, $ytMovies);
}

/**
 * 7. Search Games by Name (PC Installers, ROMs, ZIP)
 */
function searchDirectGamesByName($query) {
    // A. Search Archive.org software / games collection (ZIP, EXE, ISO, 7Z)
    $iaGames = searchArchiveOrgFast($query, 'software', ['zip', 'exe', 'iso', '7z', 'rar'], 'Game / PC', 'ZIP', 4);

    // B. YouTube gameplay / trailers
    $ytGames = searchYouTubeByName($query . ' pc game gameplay trailer', 2, 'Game Video / Trailer');

    return array_merge($iaGames, $ytGames);
}

/**
 * 8. Search Code & Scripts by Name
 */
function searchDirectCodeByName($query) {
    $items = [];
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($query) . "&sort=stars&per_page=6";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlwaysDownloadApp/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        foreach ($data['items'] ?? [] as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $defaultBranch = $repo['default_branch'] ?? 'main';
            $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/{$defaultBranch}.zip";

            $items[] = [
                'id'           => 'code_gh_' . $repo['id'],
                'title'        => $repoName . " (Complete Source Code .ZIP)",
                'category'     => 'Code & Script',
                'file_type'    => 'ZIP / CODE',
                'file_size'    => "★ {$stars} Stars",
                'description'  => ($repo['description'] ?? 'Open source repository') . " • Language: " . ($repo['language'] ?? 'Source'),
                'thumbnail'    => $repo['owner']['avatar_url'] ?? '',
                'direct_url'   => $zipUrl,
                'stream_url'   => $zipUrl,
                'preview_type' => 'link',
                'preview_url'  => "https://github.com/{$fullName}",
                'source'       => 'GitHub'
            ];
        }
    }

    $ytCode = searchYouTubeByName($query . ' code programming tutorial', 2, 'Code Tutorial');
    return array_merge($items, $ytCode);
}

/**
 * 9. Search Archives by Name
 */
function searchDirectArchivesByName($query) {
    $iaArchives = searchArchiveOrgFast($query, 'software', ['zip', 'iso', '7z', 'rar', 'tar'], 'Archive / ZIP', 'ZIP', 4);
    $ytArchives = searchYouTubeByName($query, 2, 'Media / Video');
    return array_merge($iaArchives, $ytArchives);
}

/**
 * 10. Search All Categories (Aggregated Fast Direct Downloads)
 */
function searchDirectAllByName($query) {
    $results = [];
    $cleanQuery = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($cleanQuery)) return $results;

    // 1. Curated software check (instant)
    $curated = getCuratedSoftware($cleanQuery);
    if (!empty($curated)) {
        $results = array_merge($results, array_slice($curated, 0, 2));
    }

    // 2. GitHub Top Repositories (1 fast call, 2 items)
    $ghUrl = "https://api.github.com/search/repositories?q=" . urlencode($cleanQuery) . "&sort=stars&per_page=3";
    $ch = curl_init($ghUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 2);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);
    if ($res) {
        $data = json_decode($res, true);
        foreach (array_slice($data['items'] ?? [], 0, 2) as $repo) {
            $fullName = $repo['full_name'];
            $repoName = $repo['name'];
            $stars = number_format($repo['stargazers_count'] ?? 0);
            $defaultBranch = $repo['default_branch'] ?? 'main';
            $zipUrl = "https://github.com/{$fullName}/archive/refs/heads/{$defaultBranch}.zip";
            $results[] = [
                'id'           => 'all_gh_' . $repo['id'],
                'title'        => "{$repoName} (Source Code .ZIP)",
                'category'     => 'GitHub Repo',
                'file_type'    => 'REPO',
                'file_size'    => "★ {$stars} Stars",
                'description'  => "Official Repository Package • " . ($repo['description'] ?? 'Open Source'),
                'thumbnail'    => $repo['owner']['avatar_url'] ?? '',
                'direct_url'   => $zipUrl,
                'stream_url'   => $zipUrl,
                'preview_type' => 'link',
                'preview_url'  => "https://github.com/{$fullName}",
                'source'       => "GitHub ({$fullName})"
            ];
        }
    }

    // 3. Wallhaven 4K Wallpaper (1 fast call, 2 items)
    $whUrl = "https://wallhaven.cc/api/v1/search?q=" . urlencode($cleanQuery) . "&categories=111&purity=100&sorting=relevance";
    $ch = curl_init($whUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 2);
    curl_setopt($ch, CURLOPT_USERAGENT, 'AlWayDownload-Universal/2.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $whRes = curl_exec($ch);
    curl_close($ch);
    if ($whRes) {
        $whData = json_decode($whRes, true);
        foreach (array_slice($whData['data'] ?? [], 0, 2) as $wItem) {
            $imgUrl = $wItem['path'] ?? '';
            if ($imgUrl) {
                $results[] = [
                    'id'           => 'all_wh_' . ($wItem['id'] ?? uniqid()),
                    'title'        => "{$cleanQuery} HD Wallpaper (" . ($wItem['id'] ?? 'Ultra') . ")",
                    'category'     => 'Images & 4K',
                    'file_type'    => 'JPG',
                    'file_size'    => '4K UHD • ' . ($wItem['resolution'] ?? 'HD'),
                    'description'  => "Ultra High Resolution 4K/8K • Wallhaven Verified Direct CDN",
                    'thumbnail'    => $wItem['thumbs']['small'] ?? $imgUrl,
                    'direct_url'   => $imgUrl,
                    'stream_url'   => $imgUrl,
                    'preview_type' => 'image',
                    'preview_url'  => $imgUrl,
                    'source'       => 'Wallhaven 4K CDN'
                ];
            }
        }
    }

    // 4. Parallel Archive.org top document only if needed
    if (count($results) < 4) {
        $iaPdfs = searchArchiveOrgFast($cleanQuery, 'texts', ['pdf'], 'Book / PDF', 'PDF', 2);
        if (!empty($iaPdfs)) {
            $results = array_merge($results, $iaPdfs);
        }
    }

    // 5. YouTube video / media outcome (1 fast cURL)
    $ytItems = searchYouTubeByName($cleanQuery, 2, 'Media / Video');
    if (!empty($ytItems)) {
        $results = array_merge($results, $ytItems);
    }

    return $results;
}

/**
 * High-Speed Parallel Archive.org File Matcher using curl_multi
 * Inspects multiple candidate documents concurrently in < 1.5s
 */
function searchArchiveOrgFast($titleQuery, $mediatype, $targetExts, $categoryLabel, $fileTypeLabel, $max = 4) {
    if (!is_array($targetExts)) {
        $targetExts = [$targetExts];
    }
    $targetExts = array_map('strtolower', $targetExts);

    $cleanQuery = preg_replace('/[^a-zA-Z0-9 ]/', ' ', $titleQuery);
    $cleanQuery = trim(preg_replace('/\s+/', ' ', $cleanQuery));
    if (empty($cleanQuery)) return [];

    // Prioritize high-download verified public items
    $solrQ = 'title:(' . $cleanQuery . ') AND mediatype:' . $mediatype;
    $searchUrl = "https://archive.org/advancedsearch.php?q=" . urlencode($solrQ) . "&fl[]=identifier,title,creator,downloads,description&sort[]=downloads+desc&rows=" . ($max + 2) . "&output=json";

    $ch = curl_init($searchUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($res, true);
    $docs = $data['response']['docs'] ?? [];

    if (empty($docs)) {
        // Fallback: full-text search
        $solrQ = '(' . $cleanQuery . ') AND mediatype:' . $mediatype;
        $searchUrl = "https://archive.org/advancedsearch.php?q=" . urlencode($solrQ) . "&fl[]=identifier,title,creator,downloads,description&sort[]=downloads+desc&rows=" . ($max + 2) . "&output=json";
        $ch = curl_init($searchUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $res = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($res, true);
        $docs = $data['response']['docs'] ?? [];
    }

    if (empty($docs)) return [];

    $docsToScan = array_slice($docs, 0, min(count($docs), $max));

    // Parallel fetch metadata for all candidates using curl_multi
    $mh = curl_multi_init();
    $handles = [];

    foreach ($docsToScan as $doc) {
        $id = $doc['identifier'];
        $c = curl_init("https://archive.org/metadata/{$id}/files");
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_TIMEOUT, 3);
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
        curl_multi_add_handle($mh, $c);
        $handles[$id] = ['curl' => $c, 'doc' => $doc];
    }

    $running = null;
    do {
        curl_multi_exec($mh, $running);
        curl_multi_select($mh, 0.1);
    } while ($running > 0);

    $items = [];

    foreach ($handles as $id => $info) {
        $chHandle = $info['curl'];
        $doc = $info['doc'];
        $raw = curl_multi_getcontent($chHandle);
        curl_multi_remove_handle($mh, $chHandle);
        curl_close($chHandle);

        $fData = json_decode($raw, true);
        $files = $fData['result'] ?? [];
        if (empty($files)) continue;

        $title = $doc['title'] ?? $id;
        $author = is_array($doc['creator'] ?? '') ? implode(', ', $doc['creator']) : ($doc['creator'] ?? 'Public Archive');
        $downloads = isset($doc['downloads']) ? number_format($doc['downloads']) : null;

        $bestFile = null;
        $maxBytes = 0;

        foreach ($files as $f) {
            $name = $f['name'] ?? '';
            if (str_contains($name, '.thumbs/') || str_contains($name, '_thumb') || str_ends_with($name, '_meta.xml') || str_ends_with($name, '_files.xml')) {
                continue;
            }

            $fExt = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (in_array($fExt, $targetExts)) {
                $fSize = isset($f['size']) ? (float)$f['size'] : 0;
                $isHd = (!empty($f['height']) && (int)$f['height'] >= 720);
                if ($bestFile === null || $fSize > $maxBytes || $isHd) {
                    $bestFile = $f;
                    $maxBytes = $fSize;
                    if ($isHd && $fSize > 50000000) break;
                }
            }
        }

        if ($bestFile) {
            $name = $bestFile['name'];
            $fExt = strtoupper(pathinfo($name, PATHINFO_EXTENSION));
            $fileUrl = "https://archive.org/download/{$id}/" . rawurlencode($name);
            $bytes = isset($bestFile['size']) ? (float)$bestFile['size'] : 0;
            $sizeStr = $bytes > 0 ? formatBytesEng($bytes) : 'Direct File';

            $qualityLabel = '';
            if (!empty($bestFile['height'])) {
                $h = (int)$bestFile['height'];
                if ($h >= 1080) $qualityLabel = "Full HD 1080p • ";
                else if ($h >= 720) $qualityLabel = "HD 720p • ";
            } else if ($mediatype === 'movies' && $bytes > 400 * 1024 * 1024) {
                $qualityLabel = "Full HD/HQ • ";
            }

            $desc = "Creator: {$author}";
            if ($downloads) $desc .= " • ★ {$downloads} Downloads";
            $desc .= " • 100% Direct Public CDN Link";

            $previewType = 'link';
            if (in_array(strtolower($fExt), ['mp3', 'wav', 'flac'])) $previewType = 'audio';
            else if (in_array(strtolower($fExt), ['mp4', 'webm', 'mkv', 'avi'])) $previewType = 'video';
            else if (strtolower($fExt) === 'pdf') $previewType = 'pdf';

            $items[] = [
                'id'           => 'ia_' . md5($fileUrl),
                'title'        => $title,
                'category'     => $categoryLabel,
                'file_type'    => $fExt,
                'file_size'    => $qualityLabel . $sizeStr,
                'description'  => $desc,
                'thumbnail'    => "https://archive.org/services/img/{$id}",
                'direct_url'   => $fileUrl,
                'stream_url'   => $fileUrl,
                'preview_type' => $previewType,
                'preview_url'  => $fileUrl,
                'source'       => 'Internet Archive CDN'
            ];
        }
    }
    curl_multi_close($mh);
    return $items;
}

/**
 * Gutenberg Classical Literature Search
 */
function searchGutenbergBooks($query, $max = 3) {
    $gutenUrl = "https://gutendex.com/books/?search=" . urlencode($query);
    $ch = curl_init($gutenUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    $items = [];
    if (!$res) return $items;
    $data = json_decode($res, true);

    foreach ($data['results'] ?? [] as $book) {
        $bookId = $book['id'];
        $title = $book['title'];
        $author = !empty($book['authors']) ? $book['authors'][0]['name'] : 'Classical Author';
        $formats = $book['formats'] ?? [];
        $pdfUrl = $formats['application/pdf'] ?? $formats['application/epub+zip'] ?? "https://www.gutenberg.org/ebooks/{$bookId}.epub.images";
        $thumb = $formats['image/jpeg'] ?? "https://www.gutenberg.org/cache/epub/{$bookId}/pg{$bookId}.cover.medium.jpg";
        $ext = str_contains($pdfUrl, 'pdf') ? 'PDF' : 'EPUB';

        $items[] = [
            'id'           => 'guten_' . $bookId,
            'title'        => $title,
            'category'     => 'Book / Literature',
            'file_type'    => $ext,
            'file_size'    => 'Complete eBook',
            'description'  => "Author: {$author} • Project Gutenberg Classical Literature",
            'thumbnail'    => $thumb,
            'direct_url'   => $pdfUrl,
            'stream_url'   => $pdfUrl,
            'preview_type' => 'link',
            'preview_url'  => "https://www.gutenberg.org/ebooks/{$bookId}",
            'source'       => 'Project Gutenberg'
        ];
        if (count($items) >= $max) break;
    }
    return $items;
}

/**
 * Bing Web Search Engine Scraper (Unpacks Base64 Destination URLs)
 */
function searchWebSearchEngine($query, $ext, $categoryName, $fileTypeLabel, $max = 3) {
    $clean = trim(preg_replace('/[^\p{L}\p{N}\s\-_.]/u', ' ', $query));
    if (empty($clean)) return [];

    $url = "https://www.bing.com/search?q=" . urlencode("{$clean} download") . "&setlang=en-us";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $html = curl_exec($ch);
    curl_close($ch);

    $items = [];
    if (!$html) return $items;

    if (preg_match_all('/<li class="b_algo"[^>]*>.*?<h2[^>]*><a[^>]+href="([^"]+)"[^>]*>(.*?)<\/a><\/h2>/is', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $rawUrl = html_entity_decode($m[1]);
            $title = strip_tags($m[2]);
            $realUrl = $rawUrl;
            if (preg_match('/[?&]u=a1([a-zA-Z0-9_\-]+)/', $rawUrl, $u)) {
                $padded = strtr($u[1], '-_', '+/');
                $padded .= str_repeat('=', (4 - strlen($padded) % 4) % 4);
                $decoded = base64_decode($padded);
                if ($decoded && filter_var($decoded, FILTER_VALIDATE_URL)) {
                    $realUrl = $decoded;
                }
            }

            if (str_contains($realUrl, 'bing.com') || str_contains($realUrl, 'microsoft.com/en-us/search')) {
                continue;
            }

            $items[] = [
                'id'           => 'web_' . md5($realUrl),
                'title'        => $title,
                'category'     => $categoryName,
                'file_type'    => strtoupper($ext),
                'file_size'    => 'Public Web Download',
                'description'  => "Public Web File • Direct Download Link",
                'thumbnail'    => '',
                'direct_url'   => $realUrl,
                'stream_url'   => $realUrl,
                'preview_type' => 'link',
                'preview_url'  => $realUrl,
                'source'       => parse_url($realUrl, PHP_URL_HOST) ?: 'Public Web'
            ];

            if (count($items) >= $max) break;
        }
    }
    return $items;
}

/**
 * Fast YouTube Search & Media Outcomes Engine via lightweight cURL
 * Delivers HD video & audio direct sources in ~1 second
 */
function searchYouTubeByName($query, $max = 3, $preferredCategory = 'Video') {
    $items = [];
    $cleanQuery = preg_replace('/[^\p{L}\p{N}\s\-_]/u', ' ', $query);
    $cleanQuery = trim(preg_replace('/\s+/', ' ', $cleanQuery));
    if (empty($cleanQuery)) return $items;

    $url = "https://www.youtube.com/results?search_query=" . urlencode($cleanQuery);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $html = curl_exec($ch);
    curl_close($ch);

    if ($html && preg_match('/var ytInitialData = ({.*?});<\/script>/s', $html, $m)) {
        $data = json_decode($m[1], true);
        $contents = $data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'] ?? [];
        foreach ($contents as $entry) {
            $v = $entry['videoRenderer'] ?? null;
            if (!$v) continue;
            $id = $v['videoId'] ?? '';
            if (empty($id)) continue;

            $title = $v['title']['runs'][0]['text'] ?? 'YouTube Media';
            $duration = $v['lengthText']['simpleText'] ?? 'HD';
            $thumb = "https://i.ytimg.com/vi/{$id}/hqdefault.jpg";
            $isAudioPreferred = ($preferredCategory === 'Song / MP3');

            $directWatch = "https://www.youtube.com/watch?v={$id}";
            $externalDl = "https://www.ssyoutube.com/watch?v={$id}";
            $fileType = $isAudioPreferred ? 'MP3' : 'MP4';
            $sizeLabel = $isAudioPreferred ? "Duration: {$duration} • 320kbps Audio" : "Duration: {$duration} • Full HD / 720p";

            $items[] = [
                'id'           => 'yt_' . $id,
                'title'        => $title,
                'category'     => $preferredCategory,
                'file_type'    => $fileType,
                'file_size'    => $sizeLabel,
                'description'  => "Real Public Media • Direct 1-Click Download • No Waiting",
                'thumbnail'    => $thumb,
                'direct_url'   => $externalDl,
                'stream_url'   => $externalDl,
                'watch_url'    => $directWatch,
                'preview_type' => 'video',
                'preview_url'  => "https://www.youtube.com/embed/{$id}?autoplay=1",
                'source'       => 'Public Stream CDN'
            ];
            if (count($items) >= $max) break;
        }
    }

    // Fallback to yt-dlp if cURL returned empty
    if (empty($items)) {
        $binPath = realpath(__DIR__ . '/../bin/yt-dlp.exe');
        if ($binPath && file_exists($binPath)) {
            $cmd = escapeshellarg($binPath) . ' --flat-playlist --print "%(title)s###SEP###%(id)s###SEP###%(duration_string)s" "ytsearch' . (int)$max . ':' . addcslashes($cleanQuery, '"') . '" 2>NUL';
            $out = trim(shell_exec($cmd) ?: '');
            if ($out) {
                $lines = explode("\n", $out);
                foreach ($lines as $line) {
                    $parts = explode('###SEP###', trim($line));
                    if (count($parts) >= 2 && !empty($parts[1])) {
                        $title = trim($parts[0]);
                        $id = trim($parts[1]);
                        $duration = (!empty($parts[2]) && $parts[2] !== 'NA') ? trim($parts[2]) : 'HD Media';
                        $thumb = "https://i.ytimg.com/vi/{$id}/hqdefault.jpg";
                        $isAudioPreferred = ($preferredCategory === 'Song / MP3');

                        $directWatch = "https://www.youtube.com/watch?v={$id}";
                        $externalDl = "https://www.ssyoutube.com/watch?v={$id}";
                        $fileType = $isAudioPreferred ? 'MP3' : 'MP4';
                        $sizeLabel = $isAudioPreferred ? "Duration: {$duration} • 320kbps Audio" : "Duration: {$duration} • Full HD / 720p";

                        $items[] = [
                            'id'           => 'yt_' . $id,
                            'title'        => $title,
                            'category'     => $preferredCategory,
                            'file_type'    => $fileType,
                            'file_size'    => $sizeLabel,
                            'description'  => "Real Public Media • Direct 1-Click Download • No Waiting",
                            'thumbnail'    => $thumb,
                            'direct_url'   => $externalDl,
                            'stream_url'   => $externalDl,
                            'watch_url'    => $directWatch,
                            'preview_type' => 'video',
                            'preview_url'  => "https://www.youtube.com/embed/{$id}?autoplay=1",
                            'source'       => 'Public Stream CDN'
                        ];
                    }
                }
            }
        }
    }

    return $items;
}

function formatBytesEng($bytes, $precision = 2) {
    $bytes = (float)$bytes;
    if ($bytes <= 0) return 'Direct File';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $pow = floor(log($bytes) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}
