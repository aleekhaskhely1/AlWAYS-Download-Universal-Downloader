/**
 * Always Download - Authentication Handler (AJAX)
 * 100% English UI | Login, Register, Google Sign-in & Profile dropdown
 */

const Auth = {
  currentUser: null,

  init() {
    this.bindEvents();
    this.checkSession();
  },

  bindEvents() {
    // Auth Modal Triggers
    const openLoginBtns = document.querySelectorAll('.open-login-btn');
    const openRegisterBtns = document.querySelectorAll('.open-register-btn');
    const authModal = document.getElementById('authModal');
    const closeAuthBtn = document.getElementById('closeAuthBtn');

    openLoginBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openModal('login');
      });
    });

    openRegisterBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openModal('register');
      });
    });

    if (closeAuthBtn) {
      closeAuthBtn.addEventListener('click', () => this.closeModal());
    }

    if (authModal) {
      authModal.addEventListener('click', (e) => {
        if (e.target === authModal) this.closeModal();
      });
    }

    // Tab Switches
    const tabLogin = document.getElementById('tabBtnLogin');
    const tabRegister = document.getElementById('tabBtnRegister');
    if (tabLogin && tabRegister) {
      tabLogin.addEventListener('click', () => this.switchTab('login'));
      tabRegister.addEventListener('click', () => this.switchTab('register'));
    }

    // Form Submissions
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    if (loginForm) {
      loginForm.addEventListener('submit', (e) => this.handleLogin(e));
    }

    if (registerForm) {
      registerForm.addEventListener('submit', (e) => this.handleRegister(e));
    }

    // Google Sign-In Buttons
    const googleBtns = document.querySelectorAll('.google-auth-btn');
    googleBtns.forEach(btn => {
      btn.addEventListener('click', () => this.handleGoogleAuth());
    });

    // Profile Dropdown Toggle
    const userAvatarBtn = document.getElementById('userAvatarBtn');
    const profileDropdown = document.getElementById('profileDropdown');
    if (userAvatarBtn && profileDropdown) {
      userAvatarBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        profileDropdown.classList.toggle('show');
      });

      document.addEventListener('click', () => {
        profileDropdown.classList.remove('show');
      });
    }

    // Logout Click
    const logoutBtns = document.querySelectorAll('.logout-trigger');
    logoutBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.handleLogout();
      });
    });
  },

  openModal(tab = 'login') {
    const modal = document.getElementById('authModal');
    if (modal) {
      modal.classList.add('active');
      this.switchTab(tab);
    }
  },

  closeModal() {
    const modal = document.getElementById('authModal');
    if (modal) modal.classList.remove('active');
  },

  switchTab(tab) {
    const tabLogin = document.getElementById('tabBtnLogin');
    const tabRegister = document.getElementById('tabBtnRegister');
    const formLogin = document.getElementById('loginForm');
    const formRegister = document.getElementById('registerForm');
    const modalTitle = document.getElementById('authModalTitle');

    if (tab === 'login') {
      tabLogin?.classList.add('active');
      tabRegister?.classList.remove('active');
      if (formLogin) formLogin.style.display = 'block';
      if (formRegister) formRegister.style.display = 'none';
      if (modalTitle) modalTitle.innerHTML = '🔐 Account Sign In';
    } else {
      tabRegister?.classList.add('active');
      tabLogin?.classList.remove('active');
      if (formRegister) formRegister.style.display = 'block';
      if (formLogin) formLogin.style.display = 'none';
      if (modalTitle) modalTitle.innerHTML = '📝 Create Account';
    }
  },

  async handleLogin(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;

    const email = form.email.value.trim();
    const password = form.password.value;

    if (!email || !password) {
      Toast.error('Both Email and Password are required.');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = '⌛ Verifying...';

    try {
      const formData = new FormData();
      formData.append('email', email);
      formData.append('password', password);

      const res = await fetch('api/auth.php?action=login', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();

      if (data.success) {
        Toast.success(data.message || 'Login successful!');
        this.currentUser = data.data.user;
        this.updateNavUser(this.currentUser);
        this.closeModal();
        form.reset();
      } else {
        Toast.error(data.message || 'Login failed.');
      }
    } catch (err) {
      Toast.error('Server connection error. Please verify XAMPP MySQL.');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  },

  async handleRegister(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;

    const name = form.name.value.trim();
    const phone = form.phone.value.trim();
    const email = form.email.value.trim();
    const password = form.password.value;

    if (!name || !phone || !email || !password) {
      Toast.error('All fields (Name, Phone, Email, Password) are required.');
      return;
    }

    if (password.length < 6) {
      Toast.error('Password must be at least 6 characters long.');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = '⌛ Registering...';

    try {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('phone', phone);
      formData.append('email', email);
      formData.append('password', password);

      const res = await fetch('api/auth.php?action=register', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();

      if (data.success) {
        Toast.success(data.message || 'Account created successfully!');
        this.currentUser = data.data.user;
        this.updateNavUser(this.currentUser);
        this.closeModal();
        form.reset();
      } else {
        Toast.error(data.message || 'Registration failed.');
      }
    } catch (err) {
      Toast.error('Server connection error.');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  },

  async handleGoogleAuth() {
    const googleEmail = prompt('Enter your Gmail address:', 'user@gmail.com');
    if (!googleEmail || !googleEmail.includes('@')) {
      if (googleEmail) Toast.error('Please enter a valid Gmail address.');
      return;
    }

    const googleName = googleEmail.split('@')[0].replace('.', ' ').toUpperCase();
    Toast.info('Verifying Google account credentials...');

    try {
      const formData = new FormData();
      formData.append('email', googleEmail);
      formData.append('name', googleName);
      formData.append('avatar', 'assets/images/default_avatar.svg');

      const res = await fetch('api/auth.php?action=google_auth', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();

      if (data.success) {
        Toast.success(data.message);
        this.currentUser = data.data.user;
        this.updateNavUser(this.currentUser);
        this.closeModal();
      } else {
        Toast.error(data.message || 'Google Sign-in failed.');
      }
    } catch (err) {
      Toast.error('Google authentication server error.');
    }
  },

  async handleLogout() {
    try {
      const res = await fetch('api/auth.php?action=logout');
      const data = await res.json();
      Toast.info(data.message || 'Signed out successfully.');
      this.currentUser = null;
      this.updateNavUser(null);
    } catch (err) {
      window.location.reload();
    }
  },

  async checkSession() {
    try {
      const res = await fetch('api/auth.php?action=get_user');
      const data = await res.json();
      if (data.success && data.data.logged_in) {
        this.currentUser = data.data.user;
        this.updateNavUser(this.currentUser);
      } else {
        this.updateNavUser(null);
      }
    } catch (err) {
      console.warn('Session check failed', err);
    }
  },

  updateNavUser(user) {
    const guestNav = document.getElementById('guestNavActions');
    const userNav = document.getElementById('userNavActions');
    const navUserName = document.getElementById('navUserName');
    const navUserAvatar = document.getElementById('navUserAvatar');

    if (user) {
      if (guestNav) guestNav.style.display = 'none';
      if (userNav) userNav.style.display = 'flex';
      if (navUserName) navUserName.textContent = user.name;
      if (navUserAvatar) navUserAvatar.src = user.avatar || 'assets/images/default_avatar.svg';
    } else {
      if (guestNav) guestNav.style.display = 'flex';
      if (userNav) userNav.style.display = 'none';
    }
  }
};

document.addEventListener('DOMContentLoaded', () => Auth.init());
window.Auth = Auth;
