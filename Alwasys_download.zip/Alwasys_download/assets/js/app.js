/**
 * Always Download (AlWay Download) - Core Application Script
 * 100% English UI | Real File Search Engine | Direct Stream Grabber | QR Code Generator
 */

const App = {
  currentCategory: 'all',
  activeQuery: '',
  searchTimeout: null,

  init() {
    this.bindCategoryTabs();
    this.bindSearchForm();
    this.bindSuggestions();
    this.bindQuickChips();
    this.bindHistoryDrawer();
    this.bindMediaModal();
    this.bindQrModal();
    this.loadInitialSuggestions();
  },

  /**
   * Category Filter Pills
   */
  bindCategoryTabs() {
    const tabs = document.querySelectorAll('.category-tab');
    const indicator = document.getElementById('searchCategoryIndicator');
    const searchInput = document.getElementById('searchInput');

    const placeholders = {
      all: 'Enter song, movie, PDF, software, game name or paste direct URL...',
      github: 'Search GitHub repositories, open-source tools, releases (e.g. yt-dlp, flutter, react, obs)...',
      software: 'Enter any software or app name for PC, Mac, Linux, or Mobile (e.g. VLC, Blender, VSCode, OBS, APK)...',
      image: 'Search 4K wallpapers, HD photos, artwork, or high-res graphics...',
      pdf: 'Enter book title, document topic, or author (e.g. Python, Physics, Clean Code)...',
      song: 'Enter song title, artist, or track name (e.g. Alan Walker, Lofi, Atif Aslam)...',
      movie: 'Enter movie title, video topic, or paste a YouTube URL...',
      code: 'Enter code topic, library, or script name (e.g. Python scraper, React, C++)...',
      game: 'Enter PC game name (e.g. Grand Theft Auto, Doom, Mario, Need for Speed)...',
      ios: 'Enter iOS app or game name for IPA / App Store (e.g. Delta, Minecraft, PPSSPP, VLC)...',
      archive: 'Enter package, dataset, or ZIP archive name...'
    };

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        this.currentCategory = tab.dataset.category || 'all';

        if (indicator) {
          indicator.innerHTML = `${tab.querySelector('.tab-icon').textContent} ${tab.querySelector('span:last-child').textContent}`;
        }

        if (searchInput) {
          searchInput.placeholder = placeholders[this.currentCategory] || placeholders.all;
          if (searchInput.value.trim().length >= 2) {
            this.triggerSearch(searchInput.value.trim());
          }
        }
      });
    });
  },

  /**
   * Universal Search Input & Tools
   */
  bindSearchForm() {
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const clearBtn = document.getElementById('clearSearchBtn');
    const pasteBtn = document.getElementById('pasteClipboardBtn');

    if (searchForm) {
      searchForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const val = searchInput.value.trim();
        if (val) this.triggerSearch(val);
      });
    }

    if (searchInput) {
      searchInput.addEventListener('input', () => {
        const val = searchInput.value.trim();
        if (clearBtn) clearBtn.style.display = val ? 'flex' : 'none';

        clearTimeout(this.searchTimeout);
        if (val.length >= 3 && !this.isUrl(val)) {
          this.searchTimeout = setTimeout(() => this.triggerSearch(val), 600);
        }
      });

      searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          const val = searchInput.value.trim();
          if (val) this.triggerSearch(val);
        }
      });
    }

    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        if (searchInput) {
          searchInput.value = '';
          clearBtn.style.display = 'none';
          searchInput.focus();
        }
        document.getElementById('directUrlCard')?.classList.remove('active');
      });
    }

    if (pasteBtn && searchInput) {
      pasteBtn.addEventListener('click', async () => {
        try {
          const clipText = await navigator.clipboard.readText();
          if (clipText) {
            searchInput.value = clipText.trim();
            if (clearBtn) clearBtn.style.display = 'flex';
            Toast.info('URL pasted from clipboard!');
            this.triggerSearch(clipText.trim());
          }
        } catch (err) {
          Toast.error('Clipboard access is restricted in your browser.');
        }
      });
    }
  },

  /**
   * Check if query is a URL
   */
  isUrl(str) {
    return /^https?:\/\//i.test(str) || /^www\./i.test(str) || /youtube\.com|youtu\.be/i.test(str);
  },

  /**
   * Main Search Dispatcher
   */
  async triggerSearch(query) {
    this.activeQuery = query;
    const directCard = document.getElementById('directUrlCard');
    const counterBadge = document.getElementById('resultsCountBadge');

    // Hide direct card if new search
    if (directCard) directCard.classList.remove('active');

    // Case 1: If input is a direct link or YouTube URL
    if (this.isUrl(query)) {
      this.resolveDirectUrl(query);
      return;
    }

    // Case 2: Multi-API Real Category Search
    this.showSkeletons();

    try {
      const url = `api/search.php?q=${encodeURIComponent(query)}&category=${this.currentCategory}`;
      const res = await fetch(url);
      const data = await res.json();

      if (data.success && data.data.results && data.data.results.length > 0) {
        if (counterBadge) counterBadge.textContent = `${data.data.count} Verified Downloads`;
        this.renderResults(data.data.results);
      } else {
        if (counterBadge) counterBadge.textContent = `0 Found`;
        this.renderEmptyState(`No verified direct links found for "${query}". Try another query.`);
      }
    } catch (err) {
      this.renderEmptyState('Connection error. Please check your network and try again.');
    }
  },

  /**
   * Direct URL Inspector Handler
   */
  async resolveDirectUrl(url) {
    const directCard = document.getElementById('directUrlCard');
    if (!directCard) return;

    Toast.info('⚡ Inspecting direct link and resolving stream...');

    try {
      const apiUrl = `api/direct_url.php?url=${encodeURIComponent(url)}`;
      const res = await fetch(apiUrl);
      const data = await res.json();

      if (data.success) {
        const item = data.data;
        this.renderDirectUrlCard(item);
        Toast.success('Direct URL verified!');
      } else {
        Toast.error(data.message || 'Could not resolve URL stream.');
      }
    } catch (err) {
      Toast.error('URL inspection error.');
    }
  },

  /**
   * Render Direct URL Banner Card
   */
  renderDirectUrlCard(item) {
    const card = document.getElementById('directUrlCard');
    if (!card) return;

    let html = '';
    if (item.is_youtube) {
      html = `
        <div class="direct-url-header">
          <span class="direct-url-badge">⚡ Verified YouTube Media Stream</span>
          <span style="font-size:0.8rem; color:var(--accent-cyan); font-weight:700;">100% Free Direct Access</span>
        </div>
        <div class="direct-url-body">
          <img src="${item.thumbnail}" alt="Thumbnail" class="direct-url-thumb" />
          <div class="direct-url-info">
            <h3 class="direct-url-title">${this.escapeHtml(item.title)}</h3>
            <div class="direct-url-meta">
              <span>👤 Creator: <strong>${this.escapeHtml(item.author)}</strong></span>
              <span>🔒 100% Safe Clean Media</span>
            </div>
            <div class="direct-url-actions">
              <a href="${item.downloads[0].direct_url || item.downloads[0].stream_url}" target="_blank" download="${this.escapeHtml(item.title)}.mp4" class="card-btn-download" onclick="App.logDownload('${this.escapeHtml(item.title)}', 'Video', 'MP4', '${item.downloads[0].direct_url}')">
                ⚡ Direct Download MP4 Video
              </a>
              <a href="${item.downloads[1].direct_url || item.downloads[1].stream_url}" target="_blank" download="${this.escapeHtml(item.title)}.mp3" class="nav-btn" style="background:rgba(236, 72, 153, 0.15); border-color:var(--accent-pink); color:#f472b6;" onclick="App.logDownload('${this.escapeHtml(item.title)}', 'Audio', 'MP3', '${item.downloads[1].direct_url}')">
                🎵 Download Audio Stream
              </a>
              <button class="card-btn-icon" title="Copy Direct Link" onclick="App.copyUrl('${item.downloads[0].direct_url}')">📋</button>
              <button class="card-btn-icon" title="Scan QR for Mobile" onclick="App.openQrModal('${item.downloads[0].direct_url}', '${this.escapeHtml(item.title)}')">📱</button>
              <button class="card-btn-icon" title="Preview Video" onclick="App.openVideoModal('${item.preview_embed}', '${this.escapeHtml(item.title)}')">👁️</button>
            </div>
          </div>
        </div>
      `;
    } else {
      html = `
        <div class="direct-url-header">
          <span class="direct-url-badge">⚡ Verified Direct Public File</span>
          <span style="font-size:0.8rem; color:#34d399; font-weight:700;">Ready for Direct PC / Mobile Download</span>
        </div>
        <div class="direct-url-body">
          <div style="font-size:3.2rem; width:120px; height:90px; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,0.05); border-radius:var(--radius-md);">📦</div>
          <div class="direct-url-info">
            <h3 class="direct-url-title">${this.escapeHtml(item.file_name || item.title)}</h3>
            <div class="direct-url-meta">
              <span>📊 File Size: <strong>${item.file_size}</strong></span>
              <span>🏷️ Type: <strong>${item.file_type}</strong></span>
              <span>🌐 Category: <strong>${item.category || 'Direct File'}</strong></span>
            </div>
            <div class="direct-url-actions">
              <a href="${item.direct_url}" target="_blank" download="${this.escapeHtml(item.file_name || item.title)}" class="card-btn-download" onclick="App.logDownload('${this.escapeHtml(item.file_name)}', '${item.category}', '${item.file_type}', '${item.direct_url}')">
                ⚡ Direct Download File (PC & Mobile)
              </a>
              <a href="${item.direct_url}" target="_blank" class="nav-btn" download>
                🌐 Open Raw Source
              </a>
              <button class="card-btn-icon" title="Copy Direct Link" onclick="App.copyUrl('${item.direct_url}')">📋</button>
              <button class="card-btn-icon" title="Scan QR for Mobile" onclick="App.openQrModal('${item.direct_url}', '${this.escapeHtml(item.file_name)}')">📱</button>
            </div>
          </div>
        </div>
      `;
    }

    card.innerHTML = html;
    card.classList.add('active');
    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
  },

  /**
   * Render Standard Search Result Cards
   */
  renderResults(items) {
    const grid = document.getElementById('resultsGrid');
    if (!grid) return;

    let html = '';

    items.forEach(item => {
      const typeIcons = {
        REPO: '🐙',
        GIT: '🐙',
        IPA: '🍏',
        APK: '📱',
        DMG: '🍎',
        PKG: '🍎',
        DEB: '🐧',
        APPIMAGE: '🐧',
        PDF: '📄',
        EXE: '💻',
        MSI: '💻',
        ZIP: '📦',
        MP3: '🎵',
        MP4: '🎬',
        JPG: '🖼️',
        JPEG: '🖼️',
        PNG: '🖼️',
        WEBP: '🖼️',
        SVG: '🎨',
        GIF: '🎞️',
        EPUB: '📚',
        TXT: '📝',
        PY: '🐍',
        DOCX: '📄'
      };
      const icon = typeIcons[item.file_type] || '⚡';

      html += `
        <div class="download-card">
          <div class="card-top-media">
            ${item.thumbnail ? `
              <img src="${item.thumbnail}" alt="${this.escapeHtml(item.title)}" class="card-thumb-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
              <div class="card-media-fallback" style="display:none;">${icon}</div>
            ` : `
              <div class="card-media-fallback">${icon}</div>
            `}
            <span class="card-badge-format">${item.file_type || 'FILE'}</span>
            <span class="card-badge-size">${item.file_size}</span>
          </div>

          <div class="card-content">
            <span class="card-category-tag">${item.category}</span>
            <h3 class="card-title" title="${this.escapeHtml(item.title)}">${this.escapeHtml(item.title)}</h3>
            <p class="card-desc">${this.escapeHtml(item.description || '')}</p>

            <div class="card-trust-seal" style="display:flex; justify-content:space-between; align-items:center;">
              <span>🛡️ 100% Virus-Free & Clean</span>
              ${item.relevance_score ? `<span style="background:rgba(16,185,129,0.18); color:#34d399; padding:2px 8px; border-radius:12px; font-weight:700; font-size:0.75rem; border:1px solid rgba(16,185,129,0.3);">✨ ${item.relevance_score}% Match</span>` : ''}
            </div>

            <div class="card-actions-grid">
              ${(() => {
                const streamUrl = `api/download_stream.php?url=${encodeURIComponent(item.direct_url)}&name=${encodeURIComponent(item.title)}&category=${encodeURIComponent(item.category)}`;
                return `
                  <a href="${streamUrl}" class="card-btn-download" download="${this.escapeHtml(item.title)}" onclick="App.logDownload('${this.escapeHtml(item.title)}', '${item.category}', '${item.file_type}', '${item.direct_url}')">
                    ⚡ Direct Download
                  </a>
                  <a href="${item.direct_url}" target="_blank" class="card-btn-icon" title="Open Raw CDN Link" style="text-decoration:none; display:inline-flex; align-items:center; justify-content:center;">🌐</a>
                  <button class="card-btn-icon" title="Copy Direct URL" onclick="App.copyUrl('${item.direct_url}')">📋</button>
                  <button class="card-btn-icon" title="Scan QR Code" onclick="App.openQrModal('${item.direct_url}', '${this.escapeHtml(item.title)}')">📱</button>
                `;
              })()}
              ${item.preview_type === 'audio' ? `
                <button class="card-btn-icon" title="Listen Audio" onclick="App.openAudioModal('${item.direct_url}', '${this.escapeHtml(item.title)}')">▶️</button>
              ` : ''}
              ${item.preview_type === 'video' ? `
                <button class="card-btn-icon" title="Watch Video" onclick="App.openVideoModal('${item.direct_url}', '${this.escapeHtml(item.title)}')">🎬</button>
              ` : ''}
              ${item.preview_type === 'image' ? `
                <button class="card-btn-icon" title="View Image" onclick="App.openImageModal('${item.direct_url}', '${this.escapeHtml(item.title)}')">👁️</button>
              ` : ''}
            </div>
          </div>
        </div>
      `;
    });

    grid.innerHTML = html;
  },

  /**
   * Skeletons while loading
   */
  showSkeletons() {
    const grid = document.getElementById('resultsGrid');
    if (!grid) return;
    grid.innerHTML = `
      <div class="skeleton-card"></div>
      <div class="skeleton-card"></div>
      <div class="skeleton-card"></div>
      <div class="skeleton-card"></div>
      <div class="skeleton-card"></div>
      <div class="skeleton-card"></div>
    `;
  },

  /**
   * Empty State Card
   */
  renderEmptyState(message) {
    const grid = document.getElementById('resultsGrid');
    if (!grid) return;
    grid.innerHTML = `
      <div class="empty-state-box">
        <div class="empty-state-icon">🔍</div>
        <h3 class="empty-state-title">No Direct Links Found</h3>
        <p class="empty-state-text">${message}</p>
      </div>
    `;
  },

  /**
   * Quick chip tag clicks
   */
  bindQuickChips() {
    const chips = document.querySelectorAll('.quick-tag-chip');
    const input = document.getElementById('searchInput');
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        const query = chip.dataset.query || chip.textContent.trim();
        if (input) {
          input.value = query;
          document.getElementById('clearSearchBtn').style.display = 'flex';
          const dropdown = document.getElementById('searchSuggestionsDropdown');
          if (dropdown) dropdown.style.display = 'none';
          this.triggerSearch(query);
        }
      });
    });
  },

  /**
   * Real-Time Search Suggestions Autocomplete
   */
  bindSuggestions() {
    const searchInput = document.getElementById('searchInput');
    const dropdown = document.getElementById('searchSuggestionsDropdown');
    if (!searchInput || !dropdown) return;

    let suggestTimeout = null;
    let activeIndex = -1;

    searchInput.addEventListener('input', () => {
      const query = searchInput.value.trim();
      clearTimeout(suggestTimeout);
      activeIndex = -1;

      if (query.length < 2 || App.isUrl(query)) {
        dropdown.style.display = 'none';
        dropdown.innerHTML = '';
        return;
      }

      suggestTimeout = setTimeout(async () => {
        try {
          const res = await fetch(`api/suggest.php?q=${encodeURIComponent(query)}`);
          const data = await res.json();
          if (data.success && Array.isArray(data.suggestions) && data.suggestions.length > 0) {
            App.renderSuggestions(data.suggestions, query);
          } else {
            dropdown.style.display = 'none';
            dropdown.innerHTML = '';
          }
        } catch (err) {
          dropdown.style.display = 'none';
        }
      }, 180);
    });

    searchInput.addEventListener('keydown', (e) => {
      const items = dropdown.querySelectorAll('.suggestion-item');
      if (dropdown.style.display !== 'none' && items.length > 0) {
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          activeIndex = (activeIndex + 1) % items.length;
          App.highlightSuggestion(items, activeIndex);
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          activeIndex = (activeIndex - 1 + items.length) % items.length;
          App.highlightSuggestion(items, activeIndex);
        } else if (e.key === 'Enter') {
          if (activeIndex >= 0 && items[activeIndex]) {
            e.preventDefault();
            items[activeIndex].click();
          } else {
            dropdown.style.display = 'none';
          }
        } else if (e.key === 'Escape') {
          dropdown.style.display = 'none';
        }
      }
    });

    // Dismiss suggestions on outside click
    document.addEventListener('click', (e) => {
      if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.style.display = 'none';
      }
    });

    searchInput.addEventListener('focus', () => {
      if (dropdown.innerHTML.trim() && searchInput.value.trim().length >= 2) {
        dropdown.style.display = 'block';
      }
    });
  },

  /**
   * Render suggestions into dropdown
   */
  renderSuggestions(suggestions, query) {
    const dropdown = document.getElementById('searchSuggestionsDropdown');
    if (!dropdown) return;

    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    let html = '';

    suggestions.forEach((item, index) => {
      const highlighted = item.replace(regex, '<span class="suggestion-query-highlight">$1</span>');
      html += `
        <div class="suggestion-item" data-index="${index}" data-text="${this.escapeHtml(item)}">
          <span class="suggestion-icon">🔍</span>
          <span class="suggestion-text">${highlighted}</span>
          <span class="suggestion-tag">Instant</span>
        </div>
      `;
    });

    dropdown.innerHTML = html;
    dropdown.style.display = 'block';

    dropdown.querySelectorAll('.suggestion-item').forEach(el => {
      el.addEventListener('click', () => {
        const selected = el.dataset.text;
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
          searchInput.value = selected;
          document.getElementById('clearSearchBtn').style.display = 'flex';
        }
        dropdown.style.display = 'none';
        App.triggerSearch(selected);
      });
    });
  },

  /**
   * Highlight active suggestion with keyboard
   */
  highlightSuggestion(items, index) {
    items.forEach((it, idx) => {
      if (idx === index) {
        it.classList.add('active');
        it.scrollIntoView({ block: 'nearest' });
        document.getElementById('searchInput').value = it.dataset.text;
      } else {
        it.classList.remove('active');
      }
    });
  },

  /**
   * Initial Suggestions on load
   */
  loadInitialSuggestions() {
    this.triggerSearch('Python Cheat Sheet');
  },

  /**
   * Copy URL with Toast
   */
  copyUrl(url) {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(url);
    } else {
      const tempInput = document.createElement('input');
      tempInput.value = url;
      document.body.appendChild(tempInput);
      tempInput.select();
      document.execCommand('copy');
      tempInput.remove();
    }
    Toast.success('⚡ Direct download link copied to clipboard!');
  },

  /**
   * Media Preview Player Modal
   */
  bindMediaModal() {
    const modal = document.getElementById('mediaModal');
    const closeBtn = document.getElementById('closeMediaBtn');
    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
        document.getElementById('mediaModalBody').innerHTML = '';
      });
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.remove('active');
          document.getElementById('mediaModalBody').innerHTML = '';
        }
      });
    }
  },

  openAudioModal(audioUrl, title) {
    const modal = document.getElementById('mediaModal');
    const titleEl = document.getElementById('mediaModalTitle');
    const bodyEl = document.getElementById('mediaModalBody');
    if (!modal || !bodyEl) return;

    titleEl.textContent = `🎵 Playing: ${title}`;
    bodyEl.innerHTML = `
      <div style="text-align:center; padding: 20px 0;">
        <div style="font-size:3.5rem; margin-bottom:15px;">🎧</div>
        <audio controls autoplay style="width:100%; outline:none; border-radius:30px;">
          <source src="${audioUrl}" type="audio/mpeg">
          Your browser does not support audio playback.
        </audio>
        <div style="margin-top:20px;">
          <a href="${audioUrl}" class="card-btn-download" target="_blank" download style="display:inline-flex;">⚡ Direct Download Audio</a>
        </div>
      </div>
    `;
    modal.classList.add('active');
  },

  openVideoModal(videoUrl, title) {
    const modal = document.getElementById('mediaModal');
    const titleEl = document.getElementById('mediaModalTitle');
    const bodyEl = document.getElementById('mediaModalBody');
    if (!modal || !bodyEl) return;

    titleEl.textContent = `🎬 Video: ${title}`;
    if (videoUrl.includes('embed') || videoUrl.includes('youtube')) {
      bodyEl.innerHTML = `
        <div style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:var(--radius-md);">
          <iframe src="${videoUrl}" style="position:absolute; top:0; left:0; width:100%; height:100%; border:none;" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </div>
      `;
    } else {
      bodyEl.innerHTML = `
        <video controls autoplay style="width:100%; max-height:480px; border-radius:var(--radius-md); background:#000;">
          <source src="${videoUrl}">
          Your browser does not support video playback.
        </video>
      `;
    }
    modal.classList.add('active');
  },

  openImageModal(imageUrl, title) {
    const modal = document.getElementById('mediaModal');
    const titleEl = document.getElementById('mediaModalTitle');
    const bodyEl = document.getElementById('mediaModalBody');
    if (!modal || !bodyEl) return;

    titleEl.textContent = `🖼️ Image Preview: ${title}`;
    bodyEl.innerHTML = `
      <div style="text-align:center;">
        <img src="${imageUrl}" alt="${title}" style="max-width:100%; max-height:500px; border-radius:var(--radius-md); object-fit:contain;" />
        <div style="margin-top:16px;">
          <a href="${imageUrl}" class="card-btn-download" target="_blank" download style="display:inline-flex;">⚡ Download High-Res Image</a>
        </div>
      </div>
    `;
    modal.classList.add('active');
  },

  /**
   * QR Code Modal for Mobile Downloads
   */
  bindQrModal() {
    const modal = document.getElementById('qrModal');
    const closeBtn = document.getElementById('closeQrBtn');
    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => modal.classList.remove('active'));
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('active');
      });
    }
  },

  openQrModal(url, title) {
    const modal = document.getElementById('qrModal');
    const qrContainer = document.getElementById('qrCodeContainer');
    const titleEl = document.getElementById('qrModalTitle');
    const linkEl = document.getElementById('qrModalLink');
    if (!modal || !qrContainer) return;

    titleEl.textContent = `📱 Scan to Download on Mobile`;
    linkEl.textContent = title;

    const qrUrl = `https://api.qrserver.com/com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(url)}&bgcolor=0f172a&color=00f2fe`;
    qrContainer.innerHTML = `
      <img src="${qrUrl}" alt="QR Code" style="width:230px; height:230px; border-radius:12px; border:2px solid var(--accent-cyan); box-shadow:0 0 25px rgba(6,182,212,0.3); background:#0f172a; padding:10px;" />
      <p style="margin-top:14px; font-size:0.85rem; color:var(--text-muted);">
        Scan with your smartphone camera to download this file directly to your phone.
      </p>
    `;

    modal.classList.add('active');
  },

  /**
   * Download History Drawer
   */
  bindHistoryDrawer() {
    const drawer = document.getElementById('historyDrawer');
    const overlay = document.getElementById('drawerOverlay');
    const openBtn = document.getElementById('openHistoryBtn');
    const closeBtn = document.getElementById('closeHistoryBtn');
    const clearBtn = document.getElementById('clearHistoryBtn');

    if (openBtn && drawer && overlay) {
      openBtn.addEventListener('click', (e) => {
        e.preventDefault();
        drawer.classList.add('active');
        overlay.classList.add('active');
        this.loadHistory();
      });
    }

    if (closeBtn && drawer && overlay) {
      closeBtn.addEventListener('click', () => {
        drawer.classList.remove('active');
        overlay.classList.remove('active');
      });
    }

    if (overlay) {
      overlay.addEventListener('click', () => {
        drawer.classList.remove('active');
        overlay.classList.remove('active');
      });
    }

    if (clearBtn) {
      clearBtn.addEventListener('click', async () => {
        if (confirm('Are you sure you want to clear your download history?')) {
          try {
            const res = await fetch('api/history.php?action=clear');
            const data = await res.json();
            Toast.success(data.message || 'Download history cleared!');
            this.loadHistory();
          } catch (err) {
            Toast.error('Failed to clear download history.');
          }
        }
      });
    }
  },

  async loadHistory() {
    const body = document.getElementById('historyDrawerBody');
    const badge = document.getElementById('historyCountBadge');
    if (!body) return;

    body.innerHTML = '<div style="text-align:center; padding:30px; color:var(--text-muted);">Loading history...</div>';

    try {
      const res = await fetch('api/history.php?action=get');
      const data = await res.json();

      if (data.success && data.data.history && data.data.history.length > 0) {
        if (badge) badge.textContent = data.data.history.length;
        let html = '';
        data.data.history.forEach(item => {
          html += `
            <div class="history-item-card">
              <div class="history-item-title" title="${this.escapeHtml(item.item_title)}">${this.escapeHtml(item.item_title)}</div>
              <div class="history-item-meta">
                <span>📁 ${item.item_category} (${item.file_type})</span>
                <span>📅 ${new Date(item.created_at).toLocaleDateString()}</span>
              </div>
              <a href="${item.download_url}" target="_blank" class="history-item-btn" download>
                ⚡ Re-Download
              </a>
            </div>
          `;
        });
        body.innerHTML = html;
      } else {
        if (badge) badge.textContent = '0';
        body.innerHTML = '<div style="text-align:center; padding:40px; color:var(--text-muted);">No downloads recorded yet.</div>';
      }
    } catch (err) {
      body.innerHTML = '<div style="text-align:center; padding:30px; color:#ef4444;">Failed to load history.</div>';
    }
  },

  /**
   * Log download
   */
  logDownload(title, category, type, url) {
    Toast.success(`⚡ Download started: "${title}"`);
  },

  escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());
window.App = App;
