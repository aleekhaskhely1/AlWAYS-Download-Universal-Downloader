<?php
/**
 * Real-time Search Suggestions API
 * Fetches dynamic autocomplete suggestions from public search index
 */

if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
}

$query = trim($_GET['q'] ?? '');

if (strlen($query) < 2) {
    echo json_encode(['success' => true, 'suggestions' => []]);
    exit;
}

$suggestions = [];

// Method 1: DuckDuckGo Autocomplete (Fast, no rate-limit, rich terms)
$ddgUrl = "https://duckduckgo.com/ac/?q=" . urlencode($query) . "&type=list";
$ch = curl_init($ddgUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 3);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$res = curl_exec($ch);
curl_close($ch);

if ($res) {
    $data = json_decode($res, true);
    if (!empty($data[1]) && is_array($data[1])) {
        foreach ($data[1] as $item) {
            if (is_string($item) && !empty(trim($item))) {
                $suggestions[] = trim($item);
            }
        }
    }
}

// Method 2: If DDG returned fewer than 5, try Google Chrome Suggest
if (count($suggestions) < 5) {
    $gUrl = "https://suggestqueries.google.com/complete/search?client=chrome&q=" . urlencode($query);
    $ch = curl_init($gUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $gRes = curl_exec($ch);
    curl_close($ch);

    if ($gRes) {
        $gData = json_decode($gRes, true);
        if (!empty($gData[1]) && is_array($gData[1])) {
            foreach ($gData[1] as $item) {
                if (is_string($item) && !empty(trim($item)) && !in_array(trim($item), $suggestions)) {
                    $suggestions[] = trim($item);
                }
            }
        }
    }
}

// Limit to top 8 suggestions
$suggestions = array_slice(array_unique($suggestions), 0, 8);

echo json_encode([
    'success'     => true,
    'query'       => $query,
    'suggestions' => $suggestions
]);
