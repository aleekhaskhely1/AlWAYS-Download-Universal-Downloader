<?php
require_once __DIR__ . '/config/db.php';
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}
$user = getCurrentUser();

// Fetch stats
$totalDownloads = 0;
$userHistory = [];
if ($pdo) {
    try {
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM download_history WHERE user_id = ?");
        $countStmt->execute([$user['id']]);
        $totalDownloads = $countStmt->fetchColumn() ?: 0;

        $histStmt = $pdo->prepare("
            SELECT id, item_title, item_category, file_type, file_size, download_url, created_at 
            FROM download_history 
            WHERE user_id = ? 
            ORDER BY id DESC 
            LIMIT 30
        ");
        $histStmt->execute([$user['id']]);
        $userHistory = $histStmt->fetchAll();
    } catch (Exception $e) {
        // Fallback
    }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Profile & Dashboard - AlWay Download</title>
  <link rel="icon" type="image/svg+xml" href="assets/images/logo.svg">
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    .dashboard-grid {
      display: grid;
      grid-template-columns: 320px 1fr;
      gap: 24px;
      margin: 40px 0;
    }
    .profile-card {
      background: var(--bg-card);
      border: 1px solid var(--border-glass);
      border-radius: var(--radius-lg);
      padding: 24px;
      text-align: center;
      backdrop-filter: blur(16px);
    }
    .profile-avatar-large {
      width: 90px;
      height: 90px;
      border-radius: 50%;
      border: 3px solid var(--accent-cyan);
      box-shadow: 0 0 25px rgba(6, 182, 212, 0.3);
      margin-bottom: 16px;
    }
    .stat-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 12px;
      border-radius: var(--radius-full);
      background: rgba(6, 182, 212, 0.15);
      border: 1px solid var(--accent-cyan);
      color: var(--accent-cyan);
      font-size: 0.8rem;
      font-weight: 700;
      margin-top: 8px;
    }
    .history-table-container {
      background: var(--bg-card);
      border: 1px solid var(--border-glass);
      border-radius: var(--radius-lg);
      padding: 24px;
      backdrop-filter: blur(16px);
      overflow-x: auto;
    }
    table.custom-table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 0.9rem;
    }
    table.custom-table th {
      padding: 12px;
      border-bottom: 1px solid var(--border-glass);
      color: var(--text-muted);
      font-size: 0.8rem;
      text-transform: uppercase;
    }
    table.custom-table td {
      padding: 14px 12px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.04);
      color: var(--text-main);
    }
    table.custom-table tr:hover td {
      background: rgba(255, 255, 255, 0.02);
    }
    @media (max-width: 860px) {
      .dashboard-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="ambient-glow"></div>

  <div class="app-container">
    <header class="navbar">
      <a href="index.php" class="brand-logo">
        <div class="brand-icon-box">
          <img src="assets/images/logo.svg" alt="Logo">
        </div>
        <div class="brand-text">
          <h1>AlWay Download</h1>
          <p>User Dashboard</p>
        </div>
      </a>
      <div class="nav-actions">
        <a href="index.php" class="nav-btn">← Back to Downloader</a>
        <a href="logout.php" class="nav-btn" style="color:#f87171; border-color:rgba(239,68,68,0.3);">Sign Out</a>
      </div>
    </header>

    <div class="dashboard-grid">
      <!-- Profile Card -->
      <div class="profile-card">
        <img src="<?= htmlspecialchars($user['avatar'] ?? 'assets/images/default_avatar.svg') ?>" alt="Avatar" class="profile-avatar-large">
        <h2 style="font-size: 1.3rem; font-weight: 800; color:#fff;"><?= htmlspecialchars($user['name']) ?></h2>
        <div style="font-size: 0.85rem; color: var(--accent-cyan);"><?= htmlspecialchars($user['email']) ?></div>
        <?php if (!empty($user['phone'])): ?>
          <div style="font-size: 0.82rem; color: var(--text-muted); margin-top: 4px;">📞 <?= htmlspecialchars($user['phone']) ?></div>
        <?php endif; ?>

        <div class="stat-badge">
          <span>🛡️ Verified Member</span>
        </div>

        <div style="margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--border-glass); text-align: left;">
          <div style="display:flex; justify-content:space-between; margin-bottom: 10px; font-size: 0.88rem;">
            <span style="color:var(--text-muted);">Total Downloads:</span>
            <strong style="color:#fff;"><?= $totalDownloads ?> items</strong>
          </div>
          <div style="display:flex; justify-content:space-between; font-size: 0.88rem;">
            <span style="color:var(--text-muted);">Auth Method:</span>
            <strong style="color:var(--accent-cyan); text-transform:uppercase;"><?= htmlspecialchars($user['provider'] ?? 'Local') ?></strong>
          </div>
        </div>

        <div style="margin-top: 24px;">
          <a href="index.php" class="card-btn-download" style="width: 100%;">
            ⚡ Start Downloading
          </a>
        </div>
      </div>

      <!-- History & Stats -->
      <div class="history-table-container">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
          <h3 style="font-size: 1.25rem; font-weight: 800;">📥 Your Download History</h3>
          <span style="font-size: 0.8rem; color: var(--text-dim);">Last 30 Downloads</span>
        </div>

        <?php if (empty($userHistory)): ?>
          <div class="empty-state-box" style="padding: 40px 20px;">
            <div class="empty-state-icon">📂</div>
            <h4>No download history yet.</h4>
            <p style="color:var(--text-muted); font-size:0.85rem; margin-top:6px;">Search any video, song, PDF or software from the home page to download directly!</p>
          </div>
        <?php else: ?>
          <table class="custom-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Category</th>
                <th>Format</th>
                <th>Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($userHistory as $row): ?>
                <tr>
                  <td style="font-weight: 700; max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?= htmlspecialchars($row['item_title']) ?>">
                    <?= htmlspecialchars($row['item_title']) ?>
                  </td>
                  <td><span style="color:var(--accent-cyan); font-weight:600;"><?= htmlspecialchars($row['item_category']) ?></span></td>
                  <td><span class="card-badge-format" style="position:static;"><?= htmlspecialchars($row['file_type']) ?></span></td>
                  <td style="color:var(--text-muted); font-size:0.8rem;"><?= date('M d, Y - h:i A', strtotime($row['created_at'])) ?></td>
                  <td>
                    <a href="<?= htmlspecialchars($row['download_url']) ?>" target="_blank" class="history-item-btn" download>
                      ⚡ Re-Download
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>

  </div>
</body>
</html>
