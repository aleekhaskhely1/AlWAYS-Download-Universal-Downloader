<?php
require_once __DIR__ . '/config/db.php';
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In - AlWay Download</title>
  <link rel="icon" type="image/svg+xml" href="assets/images/logo.svg">
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    .auth-page-wrapper {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
    }
    .auth-card-standalone {
      background: #0f172a;
      border: 1px solid rgba(6, 182, 212, 0.4);
      border-radius: var(--radius-lg);
      padding: 32px;
      width: 100%;
      max-width: 440px;
      box-shadow: 0 20px 50px rgba(0,0,0,0.7), 0 0 30px rgba(6, 182, 212, 0.2);
    }
  </style>
</head>
<body>
  <div class="ambient-glow"></div>

  <div class="auth-page-wrapper">
    <div class="auth-card-standalone">
      <div style="text-align: center; margin-bottom: 24px;">
        <a href="index.php" style="display:inline-block;">
          <div class="brand-icon-box" style="margin: 0 auto 12px; width:54px; height:54px;">
            <img src="assets/images/logo.svg" alt="Logo">
          </div>
        </a>
        <h2 style="font-size: 1.5rem; font-weight: 800; background: var(--gradient-brand); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
          Sign in to AlWay Download
        </h2>
        <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 4px;">
          Access your account and download history
        </p>
      </div>

      <!-- Google Sign In -->
      <button type="button" class="google-auth-btn">
        <svg viewBox="0 0 48 48">
          <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
          <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
          <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.79l7.97-6.2z"/>
          <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
        </svg>
        <span>Sign in with Google (Gmail)</span>
      </button>

      <div class="auth-divider">
        <span>OR SIGN IN WITH EMAIL</span>
      </div>

      <form id="standaloneLoginForm">
        <div class="form-group">
          <label class="form-label">Gmail / Email Address</label>
          <input type="email" id="loginEmail" class="form-input" placeholder="name@gmail.com" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" id="loginPassword" class="form-input" placeholder="••••••••" required>
        </div>
        <button type="submit" class="form-submit-btn" id="submitLoginBtn">
          🔐 Sign In
        </button>
      </form>

      <div style="text-align: center; margin-top: 20px; font-size: 0.85rem; color: var(--text-muted);">
        Don't have an account? <a href="register.php" style="color: var(--accent-cyan); font-weight: 700; text-decoration:none;">Create New Account</a>
      </div>
      <div style="text-align: center; margin-top: 10px;">
        <a href="index.php" style="color: var(--text-dim); font-size: 0.8rem; text-decoration:none;">← Back to Home Page</a>
      </div>
    </div>
  </div>

  <script src="assets/js/toast.js"></script>
  <script>
    document.getElementById('standaloneLoginForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = document.getElementById('submitLoginBtn');
      btn.disabled = true;
      btn.textContent = 'Verifying...';

      const email = document.getElementById('loginEmail').value.trim();
      const password = document.getElementById('loginPassword').value;

      try {
        const formData = new FormData();
        formData.append('email', email);
        formData.append('password', password);

        const res = await fetch('api/auth.php?action=login', {
          method: 'POST',
          body: formData
        });
        const data = await res.json();

        if (data.success) {
          Toast.success('Login successful! Redirecting...');
          setTimeout(() => window.location.href = 'index.php', 1000);
        } else {
          Toast.error(data.message || 'Invalid email or password.');
          btn.disabled = false;
          btn.textContent = '🔐 Sign In';
        }
      } catch (err) {
        Toast.error('Server connection error.');
        btn.disabled = false;
        btn.textContent = '🔐 Sign In';
      }
    });

    document.querySelector('.google-auth-btn').addEventListener('click', async () => {
      const googleEmail = prompt('Enter your Gmail address:', 'user@gmail.com');
      if (!googleEmail || !googleEmail.includes('@')) return;

      const formData = new FormData();
      formData.append('email', googleEmail);
      formData.append('name', googleEmail.split('@')[0]);

      try {
        const res = await fetch('api/auth.php?action=google_auth', {
          method: 'POST',
          body: formData
        });
        const data = await res.json();
        if (data.success) {
          Toast.success('Google Sign-in successful! Redirecting...');
          setTimeout(() => window.location.href = 'index.php', 1000);
        } else {
          Toast.error(data.message);
        }
      } catch (err) {
        Toast.error('Google Auth error');
      }
    });
  </script>
</body>
</html>
