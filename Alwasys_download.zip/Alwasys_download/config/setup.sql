-- Database Schema for Always Download (AlWay Download)
CREATE DATABASE IF NOT EXISTS `always_download_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `always_download_db`;

-- Users Table
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(30) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `auth_provider` VARCHAR(50) DEFAULT 'local',
    `avatar` VARCHAR(255) DEFAULT 'default_avatar.svg',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Download History Table
CREATE TABLE IF NOT EXISTS `download_history` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NULL,
    `item_title` VARCHAR(255) NOT NULL,
    `item_category` VARCHAR(50) NOT NULL DEFAULT 'All',
    `file_type` VARCHAR(50) DEFAULT 'FILE',
    `file_size` VARCHAR(50) DEFAULT 'Unknown',
    `source_url` TEXT NOT NULL,
    `download_url` TEXT NOT NULL,
    `ip_address` VARCHAR(45) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_user` (`user_id`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
