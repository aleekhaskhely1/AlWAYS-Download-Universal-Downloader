<?php
/**
 * Always Download - High-Performance Direct Download Stream Engine
 * Streams files & YouTube Google CDN media with forced download attachment headers
 * Guarantees direct, real binary file download on PC and Mobile devices
 */

require_once __DIR__ . '/../config/db.php';

// Turn off output buffering for high-speed streaming
if (ob_get_level()) {
    ob_end_clean();
}

$streamType = trim($_GET['type'] ?? '');
$mediaId    = trim($_GET['id'] ?? '');
$fileUrl    = trim($_GET['url'] ?? '');
$customName = trim($_GET['name'] ?? '');
$category   = trim($_GET['category'] ?? 'File');

// Handle YouTube on-the-fly resolution for Songs & Movies by Name
if (in_array($streamType, ['yt_video', 'yt_audio']) && !empty($mediaId)) {
    $cleanId = preg_replace('/[^a-zA-Z0-9_-]/', '', $mediaId);
    $binPath = realpath(__DIR__ . '/../bin/yt-dlp.exe');

    if ($binPath && file_exists($binPath)) {
        $format = ($streamType === 'yt_video') ? '136/135/134/137/160/22/18/best' : '140/251/250/249/139/bestaudio';
        $cmd = escapeshellarg($binPath) . ' -g -f ' . escapeshellarg($format) . ' "https://www.youtube.com/watch?v=' . $cleanId . '" 2>NUL';
        $resolved = trim(shell_exec($cmd) ?: '');

        if ($resolved && str_contains($resolved, 'googlevideo.com')) {
            $lines = explode("\n", $resolved);
            $fileUrl = trim($lines[0]);
            if (empty($customName)) {
                $customName = 'YouTube_' . $cleanId . ($streamType === 'yt_video' ? '.mp4' : '.mp3');
            }
        }
    }
}

if (!empty($_GET['redirect']) && !empty($fileUrl) && filter_var($fileUrl, FILTER_VALIDATE_URL)) {
    header("Location: " . $fileUrl);
    exit;
}

if (empty($fileUrl) || !filter_var($fileUrl, FILTER_VALIDATE_URL)) {
    http_response_code(400);
    die("Invalid or missing download URL.");
}

// Log download in database
if ($pdo) {
    try {
        $userId = isLoggedIn() ? (int)$_SESSION['user']['id'] : null;
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
        $title = !empty($customName) ? $customName : basename(parse_url($fileUrl, PHP_URL_PATH));
        $ext = strtoupper(pathinfo($title, PATHINFO_EXTENSION) ?: 'FILE');
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        $histStmt = $pdo->prepare("
            INSERT INTO download_history (user_id, item_title, item_category, file_type, source_url, download_url, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $histStmt->execute([$userId, substr($title, 0, 250), $category, $ext, $fileUrl, $fileUrl, $ip]);
    } catch (Exception $e) {
        // Continue downloading
    }
}
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

// Inspect headers of target file
$ch = curl_init($fileUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_NOBODY, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
curl_setopt($ch, CURLOPT_TIMEOUT, 8);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
$headerResponse = curl_exec($ch);
$contentLength = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: 'application/octet-stream';
$finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?: $fileUrl;
curl_close($ch);

// Determine download filename
if (empty($customName)) {
    if ($headerResponse && preg_match('/Content-Disposition:.*?filename=(?:"([^"]+)"|([^\s;]+))/i', $headerResponse, $matches)) {
        $customName = !empty($matches[1]) ? $matches[1] : $matches[2];
    }
    if (empty($customName)) {
        $customName = basename(parse_url($finalUrl, PHP_URL_PATH));
    }
    if (empty($customName) || $customName === '/') {
        $customName = 'AlwaysDownload_' . time() . '.bin';
    }
}

// Clean filename for safety
$safeFilename = preg_replace('/[^a-zA-Z0-9_\-\. \(\)\[\]]/', '', $customName);
if (empty(pathinfo($safeFilename, PATHINFO_EXTENSION))) {
    $urlExt = strtolower(pathinfo(parse_url($finalUrl, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
    if (!empty($urlExt)) {
        $safeFilename .= '.' . $urlExt;
    } else {
        $mimeMap = [
            'application/pdf' => 'pdf',
            'audio/mpeg' => 'mp3',
            'video/mp4' => 'mp4',
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'application/zip' => 'zip',
            'application/x-msdownload' => 'exe',
            'application/octet-stream' => 'bin'
        ];
        $detectedExt = $mimeMap[$contentType] ?? 'bin';
        $safeFilename .= '.' . $detectedExt;
    }
}

// Set Force Download Attachment Headers
header('Content-Description: File Transfer');
header('Content-Type: ' . $contentType);
header('Content-Disposition: attachment; filename="' . $safeFilename . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
if ($contentLength > 0) {
    header('Content-Length: ' . $contentLength);
}

// Stream the content in chunks directly to user output
$streamCh = curl_init($finalUrl);
curl_setopt($streamCh, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($streamCh, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($streamCh, CURLOPT_TIMEOUT, 600); // 10 minutes max stream
curl_setopt($streamCh, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
curl_setopt($streamCh, CURLOPT_WRITEFUNCTION, function($ch, $data) {
    echo $data;
    if (ob_get_level() > 0) {
        ob_flush();
    }
    flush();
    return strlen($data);
});

curl_exec($streamCh);
curl_close($streamCh);
exit;
